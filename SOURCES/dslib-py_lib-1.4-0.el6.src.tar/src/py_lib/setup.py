#!/apps/base/python2.7/bin/python
from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize
from Cython.Compiler.Main import default_options
default_options['emit_linenums'] = True
import numpy

base = "/apps/ds"

include = [
        "%s/include" % base,
        numpy.get_include(),
        "."
        ]

lib = [
        "%s/lib64" % base,
        ]

cds3 = Extension(
        name="cds3.core",
        sources=["cds3/core.pyx"],
        include_dirs=include,
        define_macros=[],
        undef_macros=[],
        library_dirs=lib,
        runtime_library_dirs=lib,
        libraries=["cds3"],
        )

cds3_enums = Extension(
        name="cds3.enums",
        sources=["cds3/enums.pyx"],
        include_dirs=include,
        define_macros=[],
        undef_macros=[],
        library_dirs=lib,
        runtime_library_dirs=lib,
        libraries=["cds3"],
        )

dsproc3 = Extension(
        name="dsproc3.core",
        sources=["dsproc3/core.pyx"],
        include_dirs=include,
        define_macros=[],
        undef_macros=[],
        library_dirs=lib,
        runtime_library_dirs=lib,
        libraries=["dsproc3"],
        )

dsproc3_enums = Extension(
        name="dsproc3.enums",
        sources=["dsproc3/enums.pyx"],
        include_dirs=include,
        define_macros=[],
        undef_macros=[],
        library_dirs=lib,
        runtime_library_dirs=lib,
        libraries=["dsproc3"],
        )

setup(
    ext_modules = cythonize([cds3,cds3_enums,dsproc3,dsproc3_enums]),
    packages = ["cds3", "dsproc3"]
)
