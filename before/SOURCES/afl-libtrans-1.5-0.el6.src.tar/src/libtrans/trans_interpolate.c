/*******************************************************************************
*
*  Your copyright notice
*
********************************************************************************
*
*  Author:
*     name:  Tim Shippert
*     phone: 5093755997
*     email: tim.shippert@pnl.gov
*
********************************************************************************
*
*  REPOSITORY INFORMATION:
*    $Revision: 14083 $
*    $Author: shippert $
*    $Date: 2012-06-20 17:35:46 +0000 (Wed, 20 Jun 2012) $
*    $State: $
*
********************************************************************************
*
*  NOTE: DOXYGEN is used to generate documentation for this file.
*
*******************************************************************************/

/** @file trans_interpolate.c
 *  1-D Interpolation transformation functions
 */
# include <stdio.h>
# include <math.h>
# include <string.h>
# include <time.h>
# include <getopt.h>
# include <regex.h>
# include "cds3.h"
# include "trans.h"


/* We'll be doing a lot of dynamic allocation, so let's make it easier */
# define CALLOC(n,t)  (t*)calloc(n, sizeof(t))
# define REALLOC(p,n,t)  (t*) realloc((char *) p, (n)*sizeof(t));

static size_t one=1;

int trans_interpolate_interface
(double *data, int *qc_data, double *odata, int *qc_odata,
 CDSVar *invar, CDSVar *outvar, int d, TRANSmetric **met) 
{

  int ni, nt, status;
  double *index=NULL, *target=NULL, range, missing_value;
  unsigned int qc_mask;
  CDSVar *incoord, *outcoord;

  // Right now, just null out our metrics, until we have some to set
  free_metric(met);

  // Pull out the stuff we need from invar, outvar, the dimension index d,
  // and the right calls to the transfrom parameter functions
  ni=invar->dims[d]->length;
  nt=outvar->dims[d]->length;

  // These mostly work straight up because coord vars are always 1D, so we
  // don't have to worry about indexing or casting correctly
  incoord = cds_get_coord_var(invar, d);
  index=(double *) cds_copy_array(incoord->type, ni,
				  incoord->data.vp,
				  CDS_DOUBLE, NULL,
				  0, NULL, NULL, NULL, NULL, NULL, NULL); 

  outcoord = cds_get_coord_var(outvar, d);
  target=(double *) cds_copy_array(outcoord->type, nt,
				  outcoord->data.vp,
				  CDS_DOUBLE, NULL,
				   0, NULL, NULL, NULL, NULL, NULL, NULL); 

  // Here's our lookup parameters
  if (cds_get_transform_param_by_dim(invar, invar->dims[d],
				     "range", CDS_DOUBLE,
				     &one, &range) == NULL) {
    range=CDS_MAX_DOUBLE;
  }


  // I'm not sure this is right anymore - but, we can't just take
  // missing_value from invar, which might be in the wrong units (i.e. not
  // doubles).  So I need to communicate our actual missing values for this
  // data set from the driver function (which does the missing_value voodoo
  // to do the type conversions and mappings correctly) to this function -
  // Either I can force in a missing value argument to each interface
  // function, or I set the transform params myself.  Hmm.
  if (cds_get_transform_param_by_dim(invar, invar->dims[d],
				     "missing_value", CDS_DOUBLE,
				     &one, &missing_value) == NULL) {
    missing_value=-9999.;
  }

  if (cds_get_transform_param_by_dim(invar, invar->dims[d],
				     "qc_mask", CDS_INT,
				     &one, &qc_mask) == NULL) {
    qc_mask=get_qc_mask(invar);
  }


  // Now just call our core function
  status=bilinear_interpolate(data, qc_data, qc_mask, index, ni, range,
			      odata, qc_odata, target, nt, missing_value);

  // Whew! we've run the transform, so we are done.
  if (index) free(index);
  if (target) free(target);

  return(status);
}

// Interpolate a give array with a given index field onto the target index
int bilinear_interpolate(double *array,
			 int *qc_array,
			 unsigned int qc_mask, 
			 double *index,
			 int ni,
			 double range, 
			 double *output,
			 int *qc_output,
			 double *target,
			 int nt,
			 double missing_value){
  int i,j,k, n1, n2;
  double u, x, y1, y2, x1, x2;
  int sign;

  // First, find whether we are monotonically increasing or decreasing;
  // this is important as we scan up to find what index is in our target
  // bin.  Take advantage of the fact that "a < b" is the same as "-a >
  // -b". 
  if (index[0] < index[1] && target[0] < target[1]) {
    sign = 1;
  } else if (index[0] > index[1] && target[0] > target[1]) {
    sign = -1;
  } else {
    ERROR(TRANS_LIB_NAME, "Target and index are not monotonically aligned");
    return(-5);
  }

  // Now just run up the flag pole, interpolating as we go.  I don't know
  // what to do about edge effects yet.  i goes up the input index field, j
  // goes up the target field.

  i=0;
  for (j=0; j<nt; j++) {

    // we will modify this as conditions warrant
    qc_output[j]=0;

    // First, do not extrapolate beyond the actual range of inputs - that's
    // just silly.
    // ACtually, we are going to be fuzzy about this - extrapolate no more
    // than half an input bin beyond our input range.  This will allow us
    // to extrapolate from 318m to 316m, for example.
    if (sign*target[j] < sign*(index[0]-((index[1]-index[0])/2.0)) ||
	sign*target[j] > sign*(index[ni-1]+((index[ni-1]-index[ni-2])/2.0))) {
      output[j]=missing_value; // we used to set it to 0, but that was
			       // RIPBE specific
      qc_set(qc_output[j], QC_OUTSIDE_RANGE);
      continue;
    }

    // run up until we find the next index that's just above this target
    // Note that this requires target values that are monotonically
    // increasing. 
    while (i < ni && sign*index[i] < sign*target[j]) { i++;}

    // All kinds of checking.  This, of course, is where I earn my money
    // This may seem like overkill, but there are a lot of exceptions I
    // need to deal with.  I need points (x1,y1) and (x2,y2), preferably
    // that bracket the value of x I'm interpolating to.  So, I do some
    // checks to find n1 and n2, which are the right indeces to use.
    // If we have bracketing points, then n1 and n2 are straightforward -
    // but if there are boundary issues then I set n1 and n2 to extrapolate
    // out.  *Then* I check to see if array[n1] and array[n2] are missing;
    // if they are, I need to iterate up and/or down until I find two good
    // points I can use.  Whew!
    if (i == ni) {
      // above the input range, so, extrapolate out from last two points
      // using the same formula
      n1=ni-2;
      n2=ni-1;
      // see below
      //qc_set(qc_output[j], QC_EXTRAPOLATE);
    } else if (i == 0) {
      // We can extrapolate down from the first two points, using the same
      // formula 
      n1=0;
      n2=1;
      // Not necessarily true, if our target point falls right on one of
      //our input points.  It's better to switch on the value of u below,
      //anyway 
      //qc_set(qc_output[j], QC_EXTRAPOLATE);
    } else {
      // we actually have input points that bracket our target, so whoopee
      n1=i-1;
      n2=i;
    }

    // If n1 is a missing value, then first scan down and then scan up to
    // find a good value, skipping the n1=n2 value.  This could lead to
    // n1>n2, if the first value is missing, but I don't think the
    // extrapolation actually cares

    // These conditionals are weird, because we need to limit check on n1
    // first, and then check all the ways that could indicate something is
    // wrong, such as n1==n2 or n1 < 0, as well as missing values or qc checks
    while ((n1 >= 0) &&
	   (fabs(array[n1]-missing_value) < 1e-8 ||
	    (qc_array[n1] & qc_mask) ||
	    ! isfinite(array[n1]))){
      qc_set(qc_output[j], QC_INTERPOLATE);
      n1--;
    }

    while ((n1 < ni) &&
	   (n1 < 0 || n1 == n2 ||
	    fabs(array[n1]-missing_value) < 1e-8 ||
	    (qc_array[n1] & qc_mask) ||
	    ! isfinite(array[n1]))) {
      qc_set(qc_output[j], QC_INTERPOLATE);
      n1++;
    }

    if (n1 >= ni) { 
      //msg_ELog(EF_PROBLEM, "bilinear_interpolate: All missing values in array");
      for (k=0;k<nt;k++) {
	output[k]=missing_value;
	qc_set(qc_output[k], QC_ALL_BAD_INPUTS);
	qc_set(qc_output[k], QC_BAD);
      }
      return(2);
    }

    // Now if n2 is a missing value, first scan up and then scan down to
    // find a good value - careful, we can't have n1=n2, so we do an extra
    // check there.  Same thing as above - limit checks "anded" with all
    // the QC indicators "or'd" together
    while ((n2 < ni) &&
	   (n2 == n1 ||
	    fabs(array[n2]-missing_value) < 1e-8 ||
	    (qc_array[n2] & qc_mask) ||
	    ! isfinite(array[n2]))) {
      qc_set(qc_output[j], QC_INTERPOLATE);
      n2++;
    }
    while ((n2 > 0) &&
	   (n2 == n1 || n2 >= ni ||
	    fabs(array[n2]-missing_value) < 1e-8 ||
	    (qc_array[n2] & qc_mask) ||
	    ! isfinite(array[n2]))) {
      qc_set(qc_output[j], QC_INTERPOLATE);
      n2--;
    }

    if (n2 >= ni || n2 <= 0 || n2 == n1) { 
      //msg_ELog(EF_PROBLEM, "bilinear_interpolate: At most one good value in array");
      for (k=0;k<nt;k++) {
	output[k]=missing_value;
	qc_set(qc_output[k], QC_ALL_BAD_INPUTS);
	qc_set(qc_output[k], QC_BAD);
      }
      return(2);
    }

    // Hopefully, we now have the input indeces to crank on
    x=target[j];

    x1=index[n1];
    x2=index[n2];

    y1=array[n1];
    y2=array[n2];

    // Final qc on range

    // First, do not extrapolate beyond the range of the actual input
    if (fabs(x-x1) > range || fabs(x-x2) > range) {
      output[j]=missing_value;
      qc_set(qc_output[j], QC_OUTSIDE_RANGE);
      continue;
    }

    // AT this point we are legally allowed to finish the interpolation,
    // with the appropriate qc flagging.

    // u is the fraction of the way up the bin to where our target value is
    u=(x-x1)/(x2-x1);

    // Now just do the weighted average
    output[j]=u*y2 + (1-u)*y1;

    // This is how we tell if we extrapolated or not; if u is not in the
    // range [0,1], then it lies outside the bin of [x1,x2], and thus is an
    // extrapolation 
    if (u < 0 || u > 1) qc_set(qc_output[j], QC_EXTRAPOLATE);


    // Finally, merge in the input QC from the two points we use.  However,
    // if u == 1, don't use n1 and if u = 0 don't use n2, because our
    // weights on those two points will be 0 in those cases.

    if (fabs(u-1) > 1e-5 && (qc_array[n1] & ~qc_mask) != 0) {
      qc_set(qc_output[j],QC_INDETERMINATE);
    }

    if (fabs(u) > 1e-5 && (qc_array[n2] & ~qc_mask) != 0) {
      qc_set(qc_output[j],QC_INDETERMINATE);
    }

  }
  return(0);
}
    
