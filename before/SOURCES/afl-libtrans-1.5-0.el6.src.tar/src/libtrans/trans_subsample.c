/*******************************************************************************
*
*  Your copyright notice
*
********************************************************************************
*
*  Author:
*     name:  Tim Shippert
*     phone: 5093755997
*     email: tim.shippert@pnl.gov
*
********************************************************************************
*
*  REPOSITORY INFORMATION:
*    $Revision: 14083 $
*    $Author: shippert $
*    $Date: 2012-06-20 17:35:46 +0000 (Wed, 20 Jun 2012) $
*    $State: $
*
********************************************************************************
*
*  NOTE: DOXYGEN is used to generate documentation for this file.
*
*******************************************************************************/

/** @file trans_interpolate.c
 *  1-D Interpolation transformation functions
 */
# include <stdio.h>
# include <math.h>
# include <string.h>
# include <time.h>
# include <getopt.h>
# include <regex.h>
# include <cds3.h>
# include "trans.h"

/* We'll be doing a lot of dynamic allocation, so let's make it easier */
# define CALLOC(n,t)  (t*)calloc(n, sizeof(t))
# define REALLOC(p,n,t)  (t*) realloc((char *) p, (n)*sizeof(t));

static size_t one=1;

int trans_subsample_interface
(double *data, int *qc_data, double *odata, int *qc_odata,
 CDSVar *invar, CDSVar *outvar, int d, TRANSmetric **met) 
{

  double *index=NULL, range, *target=NULL, missing_value;
  unsigned int qc_mask;
  int ni, nt, status;
  CDSVar *incoord, *outcoord;

  // Right now, just null out our metrics, until we have some to set
  free_metric(met);

  // Pull out the stuff we need from invar, outvar, the dimension index d,
  // and the right calls to the transfrom parameter functions
  ni=invar->dims[d]->length;
  nt=outvar->dims[d]->length;

  // These mostly work straight up because coord vars are always 1D, so we
  // don't have to worry about indexing or casting correctly
  incoord = cds_get_coord_var(invar, d);
  index=(double *) cds_copy_array(incoord->type, ni,
				  incoord->data.vp,
				  CDS_DOUBLE, NULL,
				  0, NULL, NULL, NULL, NULL, NULL, NULL); 

  outcoord = cds_get_coord_var(outvar, d);
  target=(double *) cds_copy_array(outcoord->type, nt,
				  outcoord->data.vp,
				  CDS_DOUBLE, NULL,
				   0, NULL, NULL, NULL, NULL, NULL, NULL); 

  // Here's our lookup parameters
  if (cds_get_transform_param_by_dim(invar, invar->dims[d],
				     "range", CDS_DOUBLE,
				     &one, &range) == NULL) {
    range=CDS_MAX_DOUBLE;
  }

  if (cds_get_transform_param_by_dim(invar, invar->dims[d],
				     "missing_value", CDS_DOUBLE,
				     &one, &missing_value) == NULL) {
    missing_value=-9999.;
  }

  if (cds_get_transform_param_by_dim(invar, invar->dims[d],
				     "qc_mask", CDS_INT,
				     &one, &qc_mask) == NULL) {
    qc_mask=get_qc_mask(invar);
  }

  // Now just call our core function
  status=subsample(data, qc_data, qc_mask, index, ni, range,
		   odata, qc_odata, target, nt, missing_value);

  if (index) free(index);
  if (target) free(target);

  return(status);
}

int subsample (double *array,
	       int *qc_array,
	       unsigned int qc_mask, 
	       double *index,
	       int ni,
	       double range, 
	       double *output,
	       int *qc_output,
	       double *target,
	       int nt,
	       double missing_value) {

  int i,j,iold, it;
  double d, smallest_d, dist;
  int status=0;

  // again, i indexes our input field, j indexes the target field
  iold=0;
  for (j=0; j<nt; j++) {
    qc_output[j]=0;

    // Set our scanning input value to the edge of the last window
    i=iold;

    // So, we need to find the nearest point, so start by setting
    // distance big
    dist=HUGE_VAL;
    smallest_d=dist;
    it = -1;

    // Scan up until we are at least within dist on the left side
    //while (index[i] < target[j]-range && i < ni) i++;

    // This above worked only with increasing coords, and its weird with
    // decreasing ones, so recast to just measure the distance and compare
    // with range.
    while (fabs(index[i]-target[j]) > range && i < ni) i++;

    if (i==ni) { 
      //msg_ELog(EF_PROBLEM, "subsample: no input values within range of target %f",
      // target[j]);
      status=1;
      qc_set(qc_output[j], QC_OUTSIDE_RANGE);
      output[j]=missing_value;
      continue;
    }

    // Save this i for later - we know i's less than this cannot be within
    // dist for j's greater than this, so we'll start our later scans from
    // this point.
    iold=i;
    
    // Now scan up i's until we find the one that's closest, absolutely, to
    // our target index
    //while (index[i] <= target[j]+range && i < ni) {
    while ((d=fabs(index[i]-target[j])) <= range && i < ni) {

      // keep track of smallest absolute distance, regardless of whether
      // that point is decent or not...
      if (d < smallest_d) { 
	smallest_d=d;
      }

      // ...but we only want to set this as our target distance if it
      // passes qc and whatnot
      if (d < dist && array[i] > missing_value
	  && (! (qc_array[i] & qc_mask))
	  && isfinite(array[i])) {
	  dist=d; it=i;
      }
      i++;
    }

    if (it < 0) {
      // THis is not actually a big deal - it could simply be at night.  So
      // don't overwhelm the logger with messages.
      // msg_ELog(EF_PROBLEM, "subsample: no good input values within range of target %f",
      //     target[j]);
      output[j]=missing_value;
      status=1;
      qc_set(qc_output[j], QC_ALL_BAD_INPUTS);
      qc_set(qc_output[j], QC_BAD);
      continue;
    }

    // Otherwise, use our stored it
    output[j]=array[it];
    //qc_output[j] |= qc_array[it];

    // Set qc=1 if we skipped over the actual nearest point, though
    if (dist > smallest_d) {
      qc_set(qc_output[j], QC_NOT_USING_CLOSEST);
    }
  }
   
  return(status);
}

