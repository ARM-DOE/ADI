/*******************************************************************************
*
*  Your copyright notice
*
********************************************************************************
*
*  Author:
*     name:  Tim Shippert
*     phone: 5093755997
*     email: tim.shippert@pnl.gov
*
********************************************************************************
*
*  REPOSITORY INFORMATION:
*    $Revision: 15227 $
*    $Author: shippert $
*    $Date: 2012-08-22 02:37:23 +0000 (Wed, 22 Aug 2012) $
*    $State: $
*
********************************************************************************
*
*  NOTE: DOXYGEN is used to generate documentation for this file.
*
*******************************************************************************/

/** @file trans.h
 *  typedefs for transform functions and structures.
 */

#ifndef _TRANS_H
#define _TRANS_H

#include "cds3.h"

#define TRANS_LIB_NAME "libtrans"

// Generic QC states: a superset of all the possible QC states from our
// transformations.  This probably will need some revision somewhere -
// possibly making it transform specific (although how to do that with
// different transforms in different directions, I don't know).  

// While debugging, it's nice to have them be variables rather than
// defines, but compiling with -Wall complains because we don't use them
// all in every function.  We'll decide how to do this for good later.

int QC_BAD;
int QC_INDETERMINATE;
int QC_INTERPOLATE;
int QC_EXTRAPOLATE;
int QC_NOT_USING_CLOSEST;
int QC_SOME_BAD_INPUTS;
int QC_ZERO_WEIGHT;
int QC_OUTSIDE_RANGE;
int QC_ALL_BAD_INPUTS;

// Generic qc operators - might need to move these out to another library,
// or rename them.  Or at least ifdef them.  I'm not sure all of them are
// important, but we use at least first two in the default trans functions,
// so here they are.

// I'm adding in the check for bit > 0, to disallow zero or negative bits.
// This allows us to turn off a bit by, for example, setting QC_BAD = 0
#ifndef qc_set
#  define qc_set(qc,bit) ((qc) |= (bit > 0 ? (1<<(bit-1)) : 0))
//#  define qc_set(qc,bit) ((qc) |= (1<<(bit-1)))
#endif 

#ifndef qc_check
#  define qc_check(qc,bit) ((qc) & (bit > 0 ? (1<<(bit-1)) : 0))
#endif 

#ifndef qc_clear
//   define qc_clear(qc,bit) ((qc) &= (~(1<<(bit-1))))
#   define qc_clear(qc,bit) ((qc) &= (~(bit > 0 ? (1<<(bit-1)) : 0)))
#endif

#ifndef qc_check_mask
#   define qc_check_mask(qc, mask) ((qc) & (mask))
#endif


// Now start prototyping the various functions

// Metric structure, which allows us to return metric information out of the
// interface with just one pointer.  Note that these will be set *inside* of
// the interface function, to tell the driver how to store these metrics
typedef struct _TRANSmetric {
  const char **metricnames;  //used as the tag to find sibling metric variables
  const char **metricunits;  //must define these in interface function
  int nmetrics;
  double **metrics;  // metric[nmetrics][*] - each return metric is 1D
} TRANSmetric;

// This is a structure that links an trans interface function to a
// character string name; I need it up here so that we can prototype the
// get_transform function for public use.  That's important if we want to
// make these functions available outside of the transform driver, which we
// might. 

// Adding space for dedicated 1D and 2D versions of the functions, which
// means we'll have to set them to NULL
// I'm trying something else, but this is how we might essentially overload
// the interface functions, by attaching specific 1D and 2D versions to them.
//typedef struct _TRANSfunc {
//  char *name;
//  int (*func)(double *, int*, double *, int*, CDSVar *, CDSVar*, int);
//  int (*func1D)(CDSVar *, CDSVar*, CDSVar*, CDSVar*);  
//  int (*func2D)(CDSVar *, CDSVar*, CDSVar*, CDSVar*);
//} TRANSfunc;

typedef struct _TRANSfunc {
  char *name;
  int (*func)(double *, int*, double *, int*, CDSVar *, CDSVar*, int, TRANSmetric **);
} TRANSfunc;

// I have no idea how to prototype the second argument here; it's a pointer
// to a function that takes those six arguments.
int assign_transform_function(char *, int(*)());
void assign_qc_mapping_function(int(*)());
int default_qc_mapping_function(CDSVar *, double , int);

TRANSfunc *get_transform(char*);
int cds_transform_driver(CDSVar *, CDSVar *, CDSVar *, CDSVar *);

// Default transform interface functions - they all need to be prototyped
// this way.
int trans_interpolate_interface(double*, int*,double*,int*,CDSVar*,CDSVar*,int, TRANSmetric **); 
int trans_subsample_interface(double*, int*,double*,int*,CDSVar*,CDSVar*,int, TRANSmetric **);
int trans_bin_average_interface(double*, int*,double*,int*,CDSVar*,CDSVar*,int, TRANSmetric **);
int trans_passthrough_interface(double*, int*,double*,int*,CDSVar*,CDSVar*,int, TRANSmetric **);

// No longer
//int trans_bin_average_interface_1D(CDSVar*,CDSVar*,CDSVar*, CDSVar*);

// Default transform core functions.
// It is not clear to me that this is the best place to prototype these,
// but I would like to make them available to anyone, especially people
// writing custom transforms that may default back to one of these or
// something. 

// These two have no metrics calls yet, but I should stub one in.
int bilinear_interpolate(double*,int*,unsigned int,double*,int,double,
			 double*,int*,double*,int,double);

int subsample(double*,int*,unsigned int,double*,int,double,
	      double*,int*,double*,int,double);

int bin_average(double *,int *,unsigned int, double *,double *,double *,int,
		double *,int *,double *,double *,int,double, double ***); 

// util functions - may be moved.
void *cds_get_transform_param_by_dim(void *, CDSDim*, const char *,
				     CDSDataType, size_t*, void*);
CDSVar *cds_get_metric_var(CDSVar *, char *);

unsigned int get_qc_mask(CDSVar*);

int allocate_metric(TRANSmetric **, const char **, const char **, int , int);
int free_metric (TRANSmetric **);


#endif
