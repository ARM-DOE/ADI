/*******************************************************************************
*
*  COPYRIGHT (C) 2010 Battelle Memorial Institute.  All Rights Reserved.
*
********************************************************************************
*
*  Author:
*     name:  Brian Ermold
*     phone: (509) 375-2277
*     email: brian.ermold@pnl.gov
*
********************************************************************************
*
*  REPOSITORY INFORMATION:
*    $Revision: 50680 $
*    $Author: ermold $
*    $Date: 2014-01-07 03:22:38 +0000 (Tue, 07 Jan 2014) $
*
********************************************************************************
*
*  NOTE: DOXYGEN is used to generate documentation for this file.
*
*******************************************************************************/

/** @file dsproc_version.c
 *  libdsproc3 library version.
 */

#include <string.h>

/** @privatesection */

static char *_VersionTag = "$Version: dslib-libdsproc3-2.12 $";
static char  _Version[64];

/**
 *  Private: Trim repository tag from version string if necessary.
 *
 *  @param version - version string
 */
void _dsproc_trim_version(char *version)
{
    char *vp;
    char *cp;

    if (!version) return;

    /* find colon */

    if ((*version != '$') || !(cp = strchr(version, ':'))) {
        return;
    }

    /* skip spaces */

    for (cp++; *cp == ' '; cp++);

    if (*cp == '\0') {
        *version = '\0';
        return;
    }

    /* trim leading portion of repository tag */

    vp = version;
    while (*cp != '\0') *vp++ = *cp++;

    /* trim trailing portion of repository tag */

    for (vp--; (*vp == ' ') || (*vp == '$'); vp--) {
        if (vp == version) break;
    }

    *++vp = '\0';
}

/** @publicsection */

/**
 *  libdsproc3 library version.
 *
 *  @return libdsproc3 library version
 */
const char *dsproc_lib_version(void)
{
    if (*_Version == '\0') {
        strncpy(_Version, _VersionTag, 64);
        _dsproc_trim_version(_Version);
    }

    return((const char *)_Version);
}
