/*******************************************************************************
*
*  COPYRIGHT (C) 2010 Battelle Memorial Institute.  All Rights Reserved.
*
********************************************************************************
*
*  Author:
*     name:  Brian Ermold
*     phone: (509) 375-2277
*     email: brian.ermold@pnl.gov
*
********************************************************************************
*
*  REPOSITORY INFORMATION:
*    $Revision: 50592 $
*    $Author: ermold $
*    $Date: 2013-12-31 22:12:47 +0000 (Tue, 31 Dec 2013) $
*
********************************************************************************
*
*  NOTE: DOXYGEN is used to generate documentation for this file.
*
*******************************************************************************/

/** @file dsproc.c
 *  Data System Process Library Functions.
 */

#include <signal.h>
#include <sys/resource.h>

#ifndef __GNUC__
#include <ucontext.h>
#endif

#include "dsproc3.h"
#include "dsproc_private.h"

#define COREDUMPSIZE 12000000 /**< Maximum size of core files */

/** @privatesection */

/*******************************************************************************
 *  Private Data
 */

DSProc *_DSProc = (DSProc *)NULL; /**< DSProc structure */
int     _DisableDBUpdates = 0;    /**< flag used to disable database updates */
int     _DisableLockFile  = 0;    /**< flag used to disable the lock file    */
int     _DisableMail      = 0;    /**< flag used to disable mail messages    */

static char *_LogsRoot = (char *)NULL; /**< root path to the logs directory  */
static char *_LogsDir  = (char *)NULL; /**< full path to the logs directory  */
static int   _Reprocessing = 0;        /**< reprocessing mode flag           */
static int   _DynamicDODs  = 0;        /**< dynamic DODs mode flag           */
static int   _LogInterval  = 0;        /**< log file interval                */
static int   _LogDataTime  = 0;        /**< use data time for log time       */

/*******************************************************************************
 *  Static Functions Visible Only To This Module
 */

static char *_get_logs_root()
{
    int status;

    if (!_LogsRoot) {

        status = dsenv_get_logs_root(&_LogsRoot);

        if (status < 0) {
            dsproc_set_status(DSPROC_ENOMEM);
            return((char *)NULL);
        }
        else if (status == 0) {

            ERROR( DSPROC_LIB_NAME,
                "Could not get path to logs directory\n"
                " -> the LOGS_DATA environment variable was not found\n");

            dsproc_set_status(DSPROC_ELOGSPATH);
            return((char *)NULL);
        }
    }

    return(_LogsRoot);
}

static int _lock_process(
    const char *site,
    const char *facility,
    const char *proc_name,
    const char *proc_type)
{
    char *lockfile_root;
    int   status;
    char  errstr[MAX_LOCKFILE_ERROR];

    if (_DisableLockFile) {
        return(1);
    }

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Creating process lockfile:\n");

    /* Determine path to the lockfiles directory */

    if (_LogsDir) {
        _DSProc->lockfile_path = strdup(_LogsDir);
    }
    else {

        /* Put lockfiles under the the logs root directory */

        lockfile_root = _get_logs_root();
        if (!lockfile_root) {
            return(0);
        }

        /* Create lockfile path string */

        _DSProc->lockfile_path = msngr_create_string(
            "%s/%s/lockfiles",
            lockfile_root, site);
    }

    if (!_DSProc->lockfile_path) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not create lockfile\n"
            " -> memory allocation error\n",
            site, facility, proc_name, proc_type);

        return(0);
    }

    /* Create the lockfile name */

    _DSProc->lockfile_name = msngr_create_string("%s%s-%s-%s.lock",
        site, facility, proc_name, proc_type);

    if (!_DSProc->lockfile_name) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not create lockfile\n"
            " -> memory allocation error\n",
            site, facility, proc_name, proc_type);

        free(_DSProc->lockfile_path);

        _DSProc->lockfile_path = (char *)NULL;

        return(0);
    }

    DEBUG_LV1( DSPROC_LIB_NAME,
        " - path: %s\n"
        " - name: %s\n",
        _DSProc->lockfile_path, _DSProc->lockfile_name);

    status = lockfile_create(
        _DSProc->lockfile_path, _DSProc->lockfile_name, 0,
        MAX_LOCKFILE_ERROR, errstr);

    if (status <= 0) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: %s\n",
            site, facility, proc_name, proc_type, errstr);

        free(_DSProc->lockfile_path);
        free(_DSProc->lockfile_name);

        _DSProc->lockfile_path = (char *)NULL;
        _DSProc->lockfile_name = (char *)NULL;

        return(0);
    }

    if (status == 2) {

        WARNING( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Removed stale lockfile\n"
            " -> %s/%s\n",
            site, facility, proc_name, proc_type,
            _DSProc->lockfile_path, _DSProc->lockfile_name);
    }

    return(1);
}

static void _unlock_process(void)
{
    int   status;
    char  errstr[MAX_LOCKFILE_ERROR];

    if (_DisableLockFile) {
        return;
    }

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Removing process lockfile:\n"
        " - path: %s\n"
        " - name: %s\n",
        _DSProc->lockfile_path, _DSProc->lockfile_name);

    status = lockfile_remove(
        _DSProc->lockfile_path, _DSProc->lockfile_name,
        MAX_LOCKFILE_ERROR, errstr);

    if (status < 0) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: %s\n",
            _DSProc->site, _DSProc->facility,
            _DSProc->name, _DSProc->type, errstr);
    }

    free(_DSProc->lockfile_path);
    free(_DSProc->lockfile_name);

    _DSProc->lockfile_path = (char *)NULL;
    _DSProc->lockfile_name = (char *)NULL;
}

static int _init_process_log(
    const char *site,
    const char *facility,
    const char *proc_name,
    const char *proc_type)
{
    char       *logs_root;
    char       *log_path;
    char       *log_name;
    time_t      log_time;
    struct tm   gmt;
    int         status;
    char        errstr[MAX_LOG_ERROR];

    memset(&gmt, 0, sizeof(struct tm));

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Opening process log file:\n");

    /* Determine path to the log files directory */

    if (_LogsDir) {
        log_path = strdup(_LogsDir);
    }
    else {

        /* Get the root logs directory */

        logs_root = _get_logs_root();
        if (!logs_root) {
            return(0);
        }

        /* Create log file path string */

        log_path = msngr_create_string("%s/%s/proc_logs/%s%s%s",
            logs_root, site, site, proc_name, facility);
    }

    if (!log_path) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not open process log\n"
            " -> memory allocation error\n",
            site, facility, proc_name, proc_type);

        dsproc_set_status(DSPROC_ENOMEM);
        return(0);
    }

    /* Determine the time to use in the log file name */

    if (_LogDataTime && _DSProc->cmd_line_begin) {
        log_time = _DSProc->cmd_line_begin;
    }
    else {
        log_time = time(NULL);
    }

    gmtime_r(&log_time, &gmt);

    /* Create the log file name */

    switch (_LogInterval) {
        case LOG_DAILY:
            log_name = msngr_create_string("%s%s%s.%04d%02d%02d.000000.%s",
                site, proc_name, facility,
                (gmt.tm_year + 1900), (gmt.tm_mon + 1), gmt.tm_mday, proc_type);
            break;
        case LOG_RUN:
            log_name = msngr_create_string("%s%s%s.%04d%02d%02d.%02d%02d%02d.%s",
                site, proc_name, facility,
                (gmt.tm_year + 1900), (gmt.tm_mon + 1), gmt.tm_mday,
                gmt.tm_hour, gmt.tm_min, gmt.tm_sec, proc_type);
            break;
        default: /* LOG_MONTHLY */
            log_name = msngr_create_string("%s%s%s.%04d%02d00.000000.%s",
                site, proc_name, facility,
                (gmt.tm_year + 1900), (gmt.tm_mon + 1), proc_type);
    }

    if (!log_name) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not open process log\n"
            " -> memory allocation error\n",
            site, facility, proc_name, proc_type);

        dsproc_set_status(DSPROC_ENOMEM);
        free(log_path);
        return(0);
    }

    DEBUG_LV1( DSPROC_LIB_NAME,
        " - path: %s\n"
        " - name: %s\n",
        log_path, log_name);

    status = msngr_init_log(
        log_path, log_name, (LOG_TAGS | LOG_STATS), MAX_LOG_ERROR, errstr);

    free(log_path);
    free(log_name);

    if (status == 0) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not open process log\n"
            " -> %s\n",
            site, facility, proc_name, proc_type, errstr);

        dsproc_set_status(DSPROC_ELOGOPEN);
        return(0);
    }

    return(1);
}

static int _init_provenance_log(
    const char *site,
    const char *facility,
    const char *proc_name,
    const char *proc_type)
{
    char       *logs_root;
    char       *log_path;
    char       *log_name;
    time_t      log_time;
    struct tm   gmt;
    int         status;
    char        errstr[MAX_LOG_ERROR];

    memset(&gmt, 0, sizeof(struct tm));

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Opening provenance log for: %s%s-%s-%s\n",
        site, facility, proc_name, proc_type);

    /* Determine path to the log files directory */

    if (_LogsDir) {
        log_path = strdup(_LogsDir);
    }
    else {

        /* Get the root logs directory */

        logs_root = _get_logs_root();
        if (!logs_root) {
            return(0);
        }

        /* Create log file path string */

        log_path = msngr_create_string("%s/%s/provenance/%s%s%s",
            logs_root, site, site, proc_name, facility);
    }

    if (!log_path) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not open provenance log\n"
            " -> memory allocation error\n",
            site, facility, proc_name, proc_type);

        dsproc_set_status(DSPROC_ENOMEM);
        return(0);
    }

    /* Determine the time to use in the log file name */

    if (_LogDataTime && _DSProc->cmd_line_begin) {
        log_time = _DSProc->cmd_line_begin;
    }
    else {
        log_time = time(NULL);
    }

    gmtime_r(&log_time, &gmt);

    /* Create the log file name */

    log_name = msngr_create_string("%s%s%s.%04d%02d%02d.%02d%02d%02d.%s.Provenance",
        site, proc_name, facility,
        (gmt.tm_year + 1900), (gmt.tm_mon + 1), gmt.tm_mday,
        gmt.tm_hour, gmt.tm_min, gmt.tm_sec, proc_type);

    if (!log_name) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not open provenance log\n"
            " -> memory allocation error\n",
            site, facility, proc_name, proc_type);

        dsproc_set_status(DSPROC_ENOMEM);
        free(log_path);
        return(0);
    }

    DEBUG_LV1( DSPROC_LIB_NAME,
        " - path: %s\n"
        " - name: %s\n",
        log_path, log_name);

    status = msngr_init_provenance(
        log_path, log_name, (LOG_TAGS | LOG_STATS), MAX_LOG_ERROR, errstr);

    free(log_path);
    free(log_name);

    if (status == 0) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not open provenance log\n"
            " -> %s\n",
            site, facility, proc_name, proc_type, errstr);

        dsproc_set_status(DSPROC_EPROVOPEN);
        return(0);
    }

    return(1);
}

static int _init_mail(
    MessageType  mail_type,
    char        *mail_from,
    char        *mail_subject,
    const char  *config_key)
{
    int        status;
    ProcConf **proc_conf;
    char      *mail_to;
    size_t     mail_to_length;
    char       errstr[MAX_MAIL_ERROR];
    int        i;

    if (_DisableMail) {
        return(1);
    }

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Checking database for '%s' custodians\n", config_key);

    /* Get the process configuration for this key */

    status = dsdb_get_process_config_values(_DSProc->dsdb,
        _DSProc->site, _DSProc->facility, _DSProc->type, _DSProc->name,
        config_key, &proc_conf);

    if (status == 1) {

        /* Get the length of the mail_to string */

        mail_to_length = 0;

        for (i = 0; proc_conf[i]; i++) {
            mail_to_length += strlen(proc_conf[i]->value) + 2;
        }

        /* Allocate memory for the mail_to string */

        mail_to = (char *)calloc(mail_to_length, sizeof(char));
        if (!mail_to) {

            ERROR( DSPROC_LIB_NAME,
                "Could not initialize mail message for: %s\n"
                " -> memory allocation error\n", config_key);

            dsproc_set_status(DSPROC_ENOMEM);
            return(0);
        }

        /* Create the mail_to string */

        for (i = 0; proc_conf[i]; i++) {

            DEBUG_LV1( DSPROC_LIB_NAME, " - %s\n", proc_conf[i]->value);

            if (i) strcat(mail_to, ",");

            strcat(mail_to, proc_conf[i]->value);
        }

        /* Initialize the mail message */

        status = msngr_init_mail(
            mail_type,
            mail_from,
            mail_to,
            NULL,
            mail_subject,
            MAIL_ADD_NEWLINE,
            MAX_MAIL_ERROR,
            errstr);

        /* Cleanup and exit */

        dsdb_free_process_config_values(proc_conf);
        free(mail_to);

        if (status == 0) {

            ERROR( DSPROC_LIB_NAME,
                "Could not initialize mail message for: %s\n"
                " -> %s\n", config_key, errstr);

            dsproc_set_status(DSPROC_EMAILINIT);
            return(0);
        }
    }
    else if (status < 0) {
        dsproc_set_status(DSPROC_EDBERROR);
        return(0);
    }
    else {
        DEBUG_LV1( DSPROC_LIB_NAME, " - none found\n");
    }

    return(1);
}

static void _finish_mail(
    MessageType  mail_type,
    int          mail_error_status,
    char        *status_message,
    char        *last_status_text,
    time_t       last_completed,
    time_t       last_successful,
    char        *finish_time_string)
{
    Mail *mail;
    char  last_completed_string[32];
    char  last_successful_string[32];

    if (_DisableMail) {
        return;
    }

    mail = msngr_get_mail(mail_type);
    if (!mail) {
        return;
    }

    if (mail->body[0] != '\0' || mail_error_status) {

        if (last_status_text) {
            format_secs1970(last_completed, last_completed_string);
            format_secs1970(last_successful, last_successful_string);
        }

        if (status_message && last_status_text) {
            mail_printf(mail,
                "%s\n"
                "Last Status:     %s\n"
                "Last Completed:  %s\n"
                "Last Successful: %s\n",
                status_message,
                last_status_text,
                last_completed_string,
                last_successful_string);
        }
        else if (status_message) {
            mail_printf(mail,
                "%s\n"
                "No Previous Status Has Been Recorded\n",
                status_message);
        }
        else if (last_status_text) {
            mail_printf(mail,
                "Current Status: %s\n"
                "Status: Memory allocation error creating status message\n"
                "\n"
                "Last Status:     %s\n"
                "Last Completed:  %s\n"
                "Last Successful: %s\n",
                finish_time_string,
                last_status_text,
                last_completed_string,
                last_successful_string);
        }
        else {
            mail_printf(mail,
                "Current Status: %s\n"
                "Status: Memory allocation error creating status message\n"
                "\n"
                "No Previous Status Has Been Recorded\n",
                finish_time_string);
        }
    }
}

static void _signal_handler(int sig, siginfo_t *si, void *uc)
{
    const char *status;
    int         exit_value;

    si = NULL; /* prevent "unused parameter" compiler warning */
    uc = NULL; /* prevent "unused parameter" compiler warning */

    switch (sig) {
        case SIGQUIT:
            status = "SIGQUIT: Quit (see termio(7I))";
            break;
        case SIGILL:
            status = "SIGILL: Illegal Instruction";
            break;
        case SIGTRAP:
            status = "SIGTRAP: Trace or Breakpoint Trap";
            break;
        case SIGABRT:
            status = "SIGABRT: Abort";
            break;
#ifndef __GNUC__
        case SIGEMT:
            status = "SIGEMT: Emulation Trap";
            break;
#endif
        case SIGFPE:
            status = "SIGFPE: Arithmetic Exception";
            break;
        case SIGBUS:
            status = "SIGBUS: Bus Error";
            break;
        case SIGSEGV:
            status = "SIGSEGV: Segmentation Fault";
            break;
        case SIGSYS:
            status = "SIGSYS: Bad System Call";
            break;
        case SIGHUP:
            status = "SIGHUP: Hangup (see termio(7I))";
            break;
        case SIGINT:
            status = "SIGINT: Interrupt (see termio(7I))";
            break;
        case SIGPIPE:
            status = "SIGPIPE: Broken Pipe";
            break;
        case SIGALRM:
            status = "SIGALRM: Alarm Clock";
            break;
        case SIGTERM:
            status = "SIGTERM: Terminated";
            break;
        default:
            status = "Trapped Unknown Signal Type";
    }

    ERROR( DSPROC_LIB_NAME,
        "Received Signal: %s\n", status);

    dsproc_set_status(status);

#ifndef __GNUC__
    if (msngr_debug_level) {
        printstack(fileno(stdout));
    }
#endif

    _dsproc_run_finish_process_hook();

    exit_value = dsproc_finish();
    exit(exit_value);
}

static int _init_signal_handlers(void)
{
    struct sigaction act;
#ifndef __GNUC__
    struct rlimit    rl;
#endif

    memset(&act, 0, sizeof(act));

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Initializing signal handlers\n");

    /*  act.sa_mask = sigset_t(0); */
    act.sa_handler   = 0;
    act.sa_flags     = (SA_SIGINFO);
    act.sa_sigaction = _signal_handler;

    if (sigaction(SIGHUP,  &act, 0) != 0 ||   /* Hangup (see termio(7I))    */
        sigaction(SIGINT,  &act, 0) != 0 ||   /* Interrupt (see termio(7I)) */
        sigaction(SIGQUIT, &act, 0) != 0 ||   /* Quit (see termio(7I))      */
        sigaction(SIGILL,  &act, 0) != 0 ||   /* Illegal Instruction        */
        sigaction(SIGTRAP, &act, 0) != 0 ||   /* Trace or Breakpoint Trap   */
        sigaction(SIGABRT, &act, 0) != 0 ||   /* Abort                      */
#ifndef __GNUC__
        sigaction(SIGEMT,  &act, 0) != 0 ||   /* Emulation Trap             */
#endif
        sigaction(SIGFPE,  &act, 0) != 0 ||   /* Arithmetic Exception       */
        sigaction(SIGBUS,  &act, 0) != 0 ||   /* Bus Error                  */
        sigaction(SIGSEGV, &act, 0) != 0 ||   /* Segmentation Fault         */
        sigaction(SIGSYS,  &act, 0) != 0 ||   /* Bad System Call            */
        sigaction(SIGPIPE, &act, 0) != 0 ||   /* Broken Pipe                */
        sigaction(SIGALRM, &act, 0) != 0 ||   /* Alarm Clock                */
        sigaction(SIGTERM, &act, 0) != 0) {   /* Terminated                 */

        ERROR( DSPROC_LIB_NAME,
            "Could not initialize signal handlers:\n"
            " -> %s\n", strerror(errno));

        dsproc_set_status(DSPROC_EINITSIGS);
        return(0);
    }

#ifndef __GNUC__
    /* Limit the core file size */

    rl.rlim_cur = COREDUMPSIZE;
    rl.rlim_max = COREDUMPSIZE;

    if (setrlimit(RLIMIT_CORE, &rl) == -1) {

        ERROR( DSPROC_LIB_NAME,
            "Could not set core file size limit:\n"
            " -> %s\n", strerror(errno));

        dsproc_set_status(DSPROC_EINITSIGS);
        return(0);
    }
#endif

    return(1);
}

/**
 *  Static: Initialize a data system process.
 *
 *  This function will:
 *
 *    - Initialize the mail messages
 *    - Update the process start time in the database
 *    - Initialize the signal handlers
 *    - Define non-standard unit symbols
 *    - Get process configuration information from database
 *
 *  @return
 *    - 1 if succesful
 *    - 0 if an error occurred
 */
static int _dsproc_init(void)
{
    const char *site       = _DSProc->site;
    const char *facility   = _DSProc->facility;
    const char *proc_name  = _DSProc->name;
    const char *proc_type  = _DSProc->type;
    time_t      start_time = _DSProc->start_time;
    ProcLoc    *proc_loc;
    const char *site_desc;
    char        mail_from[64];
    char        mail_subject[128];
    char       *config_value;
    int         status;

    /************************************************************
    *  Initialize mail messages
    *************************************************************/

    if (!_DisableMail) {

        snprintf(mail_from, 64, "%s%s%s", site, proc_name, facility);

        /* Error Mail */

        snprintf(mail_subject, 128,
            "%s Error: %s%s.%s ", proc_type, site, facility, proc_name);

        if (!_init_mail(MSNGR_ERROR, mail_from, mail_subject, "error_mail")) {
            return(0);
        }

        /* Warning Mail */

        snprintf(mail_subject, 128,
            "%s Warning: %s%s.%s ", proc_type, site, facility, proc_name);

        if (!_init_mail(MSNGR_WARNING, mail_from, mail_subject, "warning_mail")) {
            return(0);
        }

        /* Mentor Mail */

        snprintf(mail_subject, 128,
            "%s Message: %s%s.%s ", proc_type, site, facility, proc_name);

        if (!_init_mail(MSNGR_MAINTAINER, mail_from, mail_subject, "mentor_mail")) {
            return(0);
        }
    }

    /************************************************************
    *  Update process start time in the database
    *************************************************************/

    if (!_DisableDBUpdates) {

        if (msngr_debug_level || msngr_provenance_level) {

            char time_string[32];

            format_secs1970(start_time, time_string);

            DEBUG_LV1( DSPROC_LIB_NAME,
                "Updating process start time in database: %s\n", time_string);
        }

        status = dsdb_update_process_started(
            _DSProc->dsdb, site, facility, proc_type, proc_name, start_time);

        if (status <= 0) {

            if (status == 0) {

                ERROR( DSPROC_LIB_NAME,
                    "Could not update process start time in database\n"
                    " -> unexpected NULL result from database");
            }

            dsproc_set_status(DSPROC_EDBERROR);
            return(0);
        }
    }

    /************************************************************
    *  Initialize the signal handlers
    *************************************************************/

    if (!_init_signal_handlers()) {
        return(0);
    }

    /************************************************************
    *  Map non-standard unit symbols used by ARM to standard
    *  units in the UDUNITS-2 dictionary.
    *************************************************************/

    if (!cds_map_symbol_to_unit("C",    "degree_Celsius") ||
        !cds_map_symbol_to_unit("deg",  "degree")         ||
        !cds_map_symbol_to_unit("mb",   "millibar")       ||
        !cds_map_symbol_to_unit("srad", "steradian")      ||
        !cds_map_symbol_to_unit("unitless", "1")) {

        return(0);
    }

    /************************************************************
    *  Set the standard attributes we should exclude from the
    *  dod compare.
    *************************************************************/

    if (!_dsproc_set_standard_exclude_atts()) {
        return(0);
    }

    /************************************************************
    *  Get the process location
    *************************************************************/

    status = dsproc_get_location(&proc_loc);

    if (status <= 0) {

        if (status == 0) {

            ERROR( DSPROC_LIB_NAME,
                "Could not get process location from database\n"
                " -> unexpected NULL result from database query\n");

            dsproc_set_status(DSPROC_EDBERROR);
        }

        return(0);
    }

    /************************************************************
    *  Get the site description
    *************************************************************/

    status = dsproc_get_site_description(&site_desc);

    if (status <= 0) {

        if (status == 0) {

            ERROR( DSPROC_LIB_NAME,
                "Could not get site description from database\n"
                " -> unexpected NULL result from database query\n");

            dsproc_set_status(DSPROC_EDBERROR);
        }

        return(0);
    }

    /************************************************************
    *  Get the max runtime
    *************************************************************/

    status = dsproc_get_config_value("max_run_time", &config_value);

    if (status == 1) {
        _DSProc->max_run_time = (time_t)atoi(config_value);
        free(config_value);
    }
    else if (status == 0) {
        _DSProc->max_run_time = (time_t)0;
    }
    else {
        return(0);
    }

    /************************************************************
    *  Get the data expectation interval
    *************************************************************/

    status = dsproc_get_config_value("data_interval", &config_value);

    if (status == 1) {
        _DSProc->data_interval = (time_t)atoi(config_value);
        free(config_value);
    }
    else if (status == 0) {
        _DSProc->data_interval = (time_t)0;
    }
    else {
        return(0);
    }

    /************************************************************
    *  Get minimum valid data time
    *************************************************************/

    status = dsproc_get_config_value("min_valid_time", &config_value);

    if (status == 1) {
        _DSProc->min_valid_time = (time_t)atoi(config_value);
        free(config_value);
    }
    else if (status == 0) {
        /* 694224000 = 1992-01-01 00:00:00 */
        _DSProc->min_valid_time = (time_t)694224000;
    }
    else {
        return(0);
    }

    return(1);
}

/*******************************************************************************
 *  Private Functions Visible Only To This Library
 */

/**
 *  Free all memory used by the internal _DSProc structure.
 */
void _dsproc_destroy(void)
{
    int i;

    if (_LogsRoot) {
        free(_LogsRoot);
        _LogsRoot = (char *)NULL;
    }

    if (_LogsDir) {
        free(_LogsDir);
        _LogsDir = (char *)NULL;
    }

    if (_DSProc) {

        if (_DSProc->lockfile_path && _DSProc->lockfile_name) {
            _unlock_process();
        }

        DEBUG_LV1( DSPROC_LIB_NAME,
            "Freeing internal memory\n");

        if (_DSProc->site)      free((void *)_DSProc->site);
        if (_DSProc->facility)  free((void *)_DSProc->facility);
        if (_DSProc->name)      free((void *)_DSProc->name);
        if (_DSProc->type)      free((void *)_DSProc->type);
        if (_DSProc->version)   free((void *)_DSProc->version);
        if (_DSProc->db_alias)  free((void *)_DSProc->db_alias);
        if (_DSProc->site_desc) free((void *)_DSProc->site_desc);
        if (_DSProc->full_name) free((void *)_DSProc->full_name);

        if (_DSProc->retriever) {
            _dsproc_free_retriever();
        }

        if (_DSProc->ret_data) {
            cds_set_definition_lock(_DSProc->ret_data, 0);
            cds_delete_group(_DSProc->ret_data);
        }

        if (_DSProc->trans_data) {
            cds_set_definition_lock(_DSProc->trans_data, 0);
            cds_delete_group(_DSProc->trans_data);
        }

        if (_DSProc->location)    dsdb_free_process_location(_DSProc->location);
        if (_DSProc->dsc_inputs)  dsdb_free_ds_classes(_DSProc->dsc_inputs);
        if (_DSProc->dsc_outputs) dsdb_free_ds_classes(_DSProc->dsc_outputs);
        if (_DSProc->dsdb)        dsdb_destroy(_DSProc->dsdb);
        if (_DSProc->dqrdb)       dqrdb_destroy(_DSProc->dqrdb);

        if (_DSProc->ndatastreams) {
            for (i = 0; i < _DSProc->ndatastreams; i++) {
                _dsproc_free_datastream(_DSProc->datastreams[i]);
            }
            free(_DSProc->datastreams);
        }

        free(_DSProc);

        _DSProc = (DSProc *)NULL;
    }

    cds_free_unit_system();
    _dsproc_free_exclude_atts();
    _dsproc_free_excluded_qc_vars();
}

/** @publicsection */

/*******************************************************************************
 *  Internal Functions Visible To The Public
 */

/**
 *  Disable the datasystem process.
 *
 *  This function will set the state and status messages
 *  and cause the process to disable itself when it finishes.
 *
 *  @param  message - disable process message
 */
void dsproc_disable(const char *message)
{
    DEBUG_LV1( DSPROC_LIB_NAME,
        "Setting disable process message: '%s'\n", message);

    strncpy((char *)_DSProc->disable, message, 511);
    strncpy((char *)_DSProc->status, message, 511);
}

/**
 *  Disable the database updates.
 *
 *  Disabling database updates will prevent the process from storing
 *  runtime status information in the database. This can be used to
 *  run processes that are connected to a read-only database.
 */
void dsproc_disable_db_updates(void)
{
    DEBUG_LV1( DSPROC_LIB_NAME, "Disabling database updates\n");

    _DisableDBUpdates = 1;
}

/**
 *  Disable the creation of the process lock file.
 *
 *  Warning: Disabling the lock file will allow multiple processes to run
 *  over the top of themselves and can lead to unpredictable behavior.
 */
void dsproc_disable_lock_file(void)
{
    DEBUG_LV1( DSPROC_LIB_NAME, "Disabling lock file\n");

    _DisableLockFile = 1;
}

/**
 *  Disable the mail messages.
 */
void dsproc_disable_mail_messages(void)
{
    DEBUG_LV1( DSPROC_LIB_NAME, "Disabling mail messages\n");

    _DisableMail = 1;
}

/**
 *  Get the expected data interval.
 *
 *  This is how often we expect to get data to process.
 *
 *  @return  expected data interval
 */
time_t dsproc_get_data_interval(void)
{
    return(_DSProc->data_interval);
}

/**
 *  Get the dynamic dods mode.
 *
 *  @return
 *    - 0 = disabled
 *    - 1 = enabled
 *
 *  @see dsproc_set_dynamic_dods_mode()
 */
int dsproc_get_dynamic_dods_mode(void)
{
    return(_DynamicDODs);
}

/**
 *  Get the process max run time.
 *
 *  @return  max run time
 */
time_t dsproc_get_max_run_time(void)
{
    return(_DSProc->max_run_time);
}

/**
 *  Get the minimum valid data time for the process.
 *
 *  @return  minimum valid data time for the process
 */
time_t dsproc_get_min_valid_time(void)
{
    return(_DSProc->min_valid_time);
}

/**
 *  Get the begin and end times of the current processing interval.
 *
 *  @param  begin - output: processing interval begin time in seconds since 1970.
 *  @param  end   - output: processing interval end time in seconds since 1970.
 *
 *  @return  length of the data processing interval in seconds
 */
time_t dsproc_get_processing_interval(time_t *begin, time_t *end)
{
    if (begin) *begin = _DSProc->interval_begin;
    if (end)   *end   = _DSProc->interval_end;
    return(_DSProc->proc_interval);
}

/**
 *  Get the reprocessing mode.
 *
 *  @return
 *    - 0 = disabled
 *    - 1 = enabled
 *
 *  @see dsproc_set_reprocessing_mode()
 */
int dsproc_get_reprocessing_mode(void)
{
    return(_Reprocessing);
}

/**
 *  Get the process start time.
 *
 *  @return  start time
 */
time_t dsproc_get_start_time(void)
{
    return(_DSProc->start_time);
}

/**
 *  Get the time remaining until the max run time is reached.
 *
 *  If the max run time has been exceeded a message will be added
 *  to the log file and the process status will be set appropriately.
 *
 *  @return
 *    -  time remaining until the max run time is reached
 *    -  0 if the max run time has been exceeded
 *    - -1 if the max run time has not been set
 */
time_t dsproc_get_time_remaining(void)
{
    time_t remaining;
    time_t exceeded;

    /* All data processing loops should call this function, so we
     * add the logic to close all open datastream files that were
     * not accessed during the previous processing loop here: */

    dsproc_close_untouched_files();

    if (_DSProc->max_run_time == (time_t)0) {
        return(-1);
    }

    remaining = _DSProc->start_time
              + _DSProc->max_run_time
              - time(NULL);

    if (remaining <= 0) {

        exceeded = abs((int)remaining);

        LOG( DSPROC_LIB_NAME,
            "Exceeded max run time of %d seconds by %d seconds\n",
            (int)_DSProc->max_run_time, (int)exceeded);

        dsproc_set_status(DSPROC_ERUNTIME);
        return(0);
    }

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Processing time remaining: %d seconds\n", (int)remaining);

    return(remaining);
}

/**
 *  Set Dynamic DODs mode.
 *
 *  If the dynamic dods mode is enabled, the output DODs will be created
 *  and/or modified using all variables and associated attributes that
 *  are mapped to it.
 *
 *  @param  mode - dynamic dods mode (0 = disabled, 1 = enabled)
 *
 *  @see dsproc_get_dynamic_dods_mode()
 */
void dsproc_set_dynamic_dods_mode(int mode)
{
    DEBUG_LV1( DSPROC_LIB_NAME,
        "Setting dynamic DODs mode to: %d\n", mode);

    _DynamicDODs = mode;
}

/**
 *  Set Log file directory.
 *
 *  @param  log_dir - full path to the log files directory
 *
 *  @return
 *    - 1 if successful
 *    - 0 if a memory allocation error occurred
 */
int dsproc_set_log_dir(const char *log_dir)
{
    _LogsDir = strdup(log_dir);

    if (!_LogsDir) {

        ERROR( DSPROC_LIB_NAME,
            "Could not set log file directory: %s\n"
            " -> memory allocation error\n",
            log_dir);

        dsproc_set_status(DSPROC_ENOMEM);
        return(0);
    }

    return(1);
}

/**
 *  Set Log file interval.
 *
 *  @param  interval       - log file interval:
 *                             - LOG_MONTHLY = create monthly log files
 *                             - LOG_DAILY   = create daily log files
 *                             - LOG_RUN     = create one log file per run
 *
 *  @param  use_begin_time - VAP Only: flag indicating if the begin time
 *                           specified on the command line should be used
 *                           for the log file time.
 */
void dsproc_set_log_interval(LogInterval interval, int use_begin_time)
{
    _LogInterval  = interval;
    _LogDataTime  = use_begin_time;
}

/**
 *  Set the begin and end times for the current processing interval.
 *
 *  This function can be used to override the begin and end times
 *  of the current processing interval and should be called from
 *  the pre-retrieval hook function.
 *
 *  @param  begin_time - begin time in seconds since 1970.
 *  @param  end_time   - end time in seconds since 1970.
 */
void dsproc_set_processing_interval(
    time_t begin_time,
    time_t end_time)
{
    char ts1[32], ts2[32];

    _DSProc->interval_begin = begin_time;
    _DSProc->interval_end   = end_time;
    _DSProc->proc_interval  = end_time - begin_time;

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Setting processing interval:\n"
        " - begin time: %s\n"
        " - end time:   %s\n"
        " - interval:   %d seconds\n",
        format_secs1970(begin_time, ts1),
        format_secs1970(end_time,   ts2),
        _DSProc->proc_interval);
}

/**
 *  Set the offset to apply to the processing interval.
 *
 *  This function can be used to shift the processing interval and
 *  should be called from either the init-process or pre-retrieval
 *  hook function.
 *
 *  @param  offset - offset in seconds
 */
void dsproc_set_processing_interval_offset(time_t offset)
{
    DEBUG_LV1( DSPROC_LIB_NAME,
        "Setting processing interval offset to: %d seconds\n", (int)offset);

    _DSProc->interval_offset = offset;
}

/**
 *  Set the reprocessing mode.
 *
 *  If the reprocessing mode is enabled, the time validatation functions will
 *  not check if the data time is earlier than that of the latest processed
 *  data time.
 *
 *  @param  mode - reprocessing mode (0 = disabled, 1 = enabled)
 *
 *  @see dsproc_get_reprocessing_mode()
 */
void dsproc_set_reprocessing_mode(int mode)
{
    DEBUG_LV1( DSPROC_LIB_NAME,
        "Setting reprocessing mode to: %d\n", mode);

    _Reprocessing = mode;
}

/**
 *  Initialize a data system process.
 *
 *  This function will:
 *    - Parse the command line
 *    - Connect to the database
 *    - Open the process log file
 *    - Initialize the mail messages
 *    - Update the process start time in the database
 *    - Initialize the signal handlers
 *    - Define non-standard unit symbols
 *    - Get process configuration information from database
 *    - Initialize input and output datastreams
 *    - Initialize the data retrival structures
 *
 *  The database connection will be left open when this function returns
 *  to allow the user's init_process() function to access the database without
 *  the need to reconnect to it. The database connection should be closed
 *  after the user's init_process() function returns.
 *
 *  The program will terminate inside this function if the -h (help) or
 *  -v (version) options are specified on the command line (exit value 0),
 *  or if an error occurs (exit value 1).
 *
 *  @param  argc         - command line argument count
 *  @param  argv         - command line argument vector
 *  @param  proc_model   - processing model to use
 *  @param  proc_version - process version
 *  @param  nproc_names  - number of valid process names
 *  @param  proc_names   - list of valid process names
 */
void dsproc_initialize(
    int          argc,
    char       **argv,
    ProcModel    proc_model,
    const char  *proc_version,
    int          nproc_names,
    const char **proc_names)
{
    const char *program_name = argv[0];
    time_t      start_time   = time(NULL);
    const char *site;
    const char *facility;
    const char *proc_name;
    const char *proc_type;
    int         db_attempts;
    FamProc    *fam_proc;
    char       *config_value;
    int         status;
    int         exit_value;

    /************************************************************
    *  Create the DSPROC structure
    *************************************************************/

    if (_DSProc) {
        dsproc_finish();
    }

    _DSProc = (DSProc *)calloc(1, sizeof(DSProc));
    if (!_DSProc) {

        fprintf(stderr,
            "%s: Memory allocation error initializing process\n",
            program_name);

        exit(1);
    }

    _DSProc->start_time = start_time;
    _DSProc->model      = proc_model;

    /* set version */

    if (proc_version) {
        if (!(_DSProc->version = strdup(proc_version))) {
            goto MEMORY_ERROR;
        }
        _dsproc_trim_version((char *)_DSProc->version);
    }
    else {
        if (!(_DSProc->version = strdup("Unknown"))) {
            goto MEMORY_ERROR;
        }
    }

    /* set process name if not from the command line */

    if (nproc_names == 1) {
        if (!(_DSProc->name = strdup(proc_names[0]))) {
            goto MEMORY_ERROR;
        }
    }

    /************************************************************
    *  Set process type and parse command line arguments
    *************************************************************/

    if (proc_model == PM_INGEST) {
        if (!(_DSProc->type = strdup("Ingest"))) {
            goto MEMORY_ERROR;
        }
        _dsproc_ingest_parse_args(argc, argv, nproc_names, proc_names);
    }
    else {
        if (!(_DSProc->type = strdup("VAP"))) {
            goto MEMORY_ERROR;
        }
        _dsproc_vap_parse_args(argc, argv, nproc_names, proc_names);
    }

    if (!(_DSProc->full_name = msngr_create_string(
        "%s-%s", _DSProc->name, _DSProc->type))) {

        goto MEMORY_ERROR;
    }

    /************************************************************
    *  Initialize the process
    *************************************************************/

    site      = _DSProc->site;
    facility  = _DSProc->facility;
    proc_name = _DSProc->name;
    proc_type = _DSProc->type;

    DEBUG_LV1_BANNER( DSPROC_LIB_NAME,
        "INITIALIZING PROCESS: %s%s-%s-%s\n",
        site, facility, proc_name, proc_type);

    if (!_DSProc->db_alias) {
        if (!(_DSProc->db_alias = strdup("dsdb_data"))) {
            goto MEMORY_ERROR;
        }
    }

    /************************************************************
    *  Create the lockfile for this process
    *************************************************************/

    if (!_DisableLockFile) {
        if (!_lock_process(site, facility, proc_name, proc_type)) {
            _dsproc_destroy();
            exit(1);
        }
    }

    /************************************************************
    *  Connect to the database
    *************************************************************/

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Initializing database connection: %s\n", _DSProc->db_alias);

    _DSProc->dsdb = dsdb_create(_DSProc->db_alias);
    if (!_DSProc->dsdb) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not initialize database connection\n",
            site, facility, proc_name, proc_type);

        _dsproc_destroy();
        exit(1);
    }

    db_attempts = dsdb_connect(_DSProc->dsdb);

    if (db_attempts == 0) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Could not connect to database\n",
            site, facility, proc_name, proc_type);

        _dsproc_destroy();
        exit(1);
    }

    if (msngr_debug_level) {

        if (_DSProc->dsdb->dbconn->db_host[0] != '\0') {
            DEBUG_LV1( DSPROC_LIB_NAME,
                " - db_host: %s\n", _DSProc->dsdb->dbconn->db_host);
        }

        if (_DSProc->dsdb->dbconn->db_name[0] != '\0') {
            DEBUG_LV1( DSPROC_LIB_NAME,
                " - db_name: %s\n", _DSProc->dsdb->dbconn->db_name);
        }

        if (_DSProc->dsdb->dbconn->db_user[0] != '\0') {
            DEBUG_LV1( DSPROC_LIB_NAME,
                " - db_user: %s\n", _DSProc->dsdb->dbconn->db_user);
        }
    }

    if (_DSProc->dsdb->dbconn->db_type == DB_WSPC) {

        DEBUG_LV1( DSPROC_LIB_NAME,
            " - using read-only web service connection\n"
            " - disabled database updates\n"
            " - disabled mail messages\n");

        _DisableDBUpdates = 1;
        _DisableMail      = 1;
    }

    /************************************************************
    *  Make sure this is a valid datasystem process
    *************************************************************/

    status = dsdb_get_family_process(
        _DSProc->dsdb, site, facility, proc_type, proc_name, &fam_proc);

    if (status <= 0) {

        ERROR( DSPROC_LIB_NAME,
            "%s%s-%s-%s: Process not found in database\n",
            site, facility, proc_name, proc_type);

        _dsproc_destroy();
        exit(1);
    }

    dsdb_free_family_process(fam_proc);

    /************************************************************
    *  Open the provenance log
    *************************************************************/

    if (msngr_provenance_level) {

        if (!_init_provenance_log(site, facility, proc_name, proc_type)) {
            _dsproc_destroy();
            exit(1);
        }

        PROVENANCE_LV1( DSPROC_LIB_NAME,
            "Initializing process: %s%s-%s-%s\n",
            site, facility, proc_name, proc_type);
    }

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Process version: %s\n", _DSProc->version);

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Library versions:\n"
        " - libmsngr:    %s\n"
        " - libarmutils: %s\n"
        " - libcds3:     %s\n"
        " - libncds3:    %s\n"
        " - libdbconn:   %s\n"
        " - libdsdb3:    %s\n"
        " - libdsproc3:  %s\n",
        msngr_lib_version(),
        armutils_lib_version(),
        cds_lib_version(),
        ncds_lib_version(),
        dbconn_lib_version(),
        dsdb_lib_version(),
        dsproc_lib_version());

    if (msngr_provenance_level) {

        if (_DSProc->lockfile_path && _DSProc->lockfile_name) {

            PROVENANCE_LV1( DSPROC_LIB_NAME,
                "Created process lockfile:\n"
                " - path: %s\n"
                " - name: %s\n",
                _DSProc->lockfile_path,
                _DSProc->lockfile_name);
        }

        PROVENANCE_LV1( DSPROC_LIB_NAME,
            "Using database connection:\n");

        if (_DSProc->dsdb->dbconn->db_host[0] != '\0') {
            PROVENANCE_LV1( DSPROC_LIB_NAME,
                " - db_host: %s\n", _DSProc->dsdb->dbconn->db_host);
        }

        if (_DSProc->dsdb->dbconn->db_name[0] != '\0') {
            PROVENANCE_LV1( DSPROC_LIB_NAME,
                " - db_name: %s\n", _DSProc->dsdb->dbconn->db_name);
        }

        if (_DSProc->dsdb->dbconn->db_user[0] != '\0') {
            PROVENANCE_LV1( DSPROC_LIB_NAME,
                " - db_user: %s\n", _DSProc->dsdb->dbconn->db_user);
        }

        if (_DSProc->dsdb->dbconn->db_type == DB_WSPC) {
            PROVENANCE_LV1( DSPROC_LIB_NAME,
                " - using read-only web service connection\n"
                " - disabled database updates\n"
                " - disabled mail messages\n");
        }
    }

    /************************************************************
    *  Open the log file
    *************************************************************/

    if (!_init_process_log(site, facility, proc_name, proc_type)) {
        _dsproc_destroy();
        exit(1);
    }

    /* Log the number of database connect attempts (if greater than 1) */

    if (db_attempts > 1) {

        LOG( DSPROC_LIB_NAME,
            "\nDB_ATTEMPTS: It took %d attempts to connect to the database.\n",
            db_attempts);
    }

    /************************************************************
    *  After this point the dsproc_finish() function should be
    *  used to cleanup before exiting.
    *************************************************************/

    if (!_dsproc_init()) {
        exit_value = dsproc_finish();
        exit(exit_value);
    }

    if (proc_model == PM_INGEST) {

        /************************************************************
        *  Initialize an Ingest process
        *************************************************************/

        /* Initialize the input datastreams */

        if (!_dsproc_init_input_datastreams()) {
            exit_value = dsproc_finish();
            exit(exit_value);
        }

        /* Initialize the output datastreams */

        if (!_dsproc_init_output_datastreams()) {
            exit_value = dsproc_finish();
            exit(exit_value);
        }
    }
    else {

        /************************************************************
        *  Initialize a VAP process
        *************************************************************/

        /* Get the data processing interval */

        status = dsproc_get_config_value("processing_interval", &config_value);

        if (status == 1) {
            _DSProc->proc_interval = (time_t)atoi(config_value);
            free(config_value);
            
            if (_DSProc->proc_interval <= 0) {
                status = 0;
            }
        }
        else if (status < 0) {
            exit_value = dsproc_finish();
            exit(exit_value);
        }

        if (status == 0) {

            if (_DSProc->cmd_line_end > _DSProc->cmd_line_begin) {

                _DSProc->proc_interval =
                    _DSProc->cmd_line_end - _DSProc->cmd_line_begin;

                DEBUG_LV1( DSPROC_LIB_NAME,
                    "Processing interval not defined or <= 0:\n"
                    " - using interval between begin and end times specified on command line: %d seconds\n",
                    _DSProc->proc_interval);
            }
            else {

                _DSProc->proc_interval = 86400;

                DEBUG_LV1( DSPROC_LIB_NAME,
                    "Processing interval not defined or <= 0:\n"
                    " - using default value: %d seconds\n",
                    _DSProc->proc_interval);
            }
        }

        /* Set the end time if it was not specified on the command line */

        if (!_DSProc->cmd_line_end) {
            _DSProc->cmd_line_end =
                _DSProc->cmd_line_begin + _DSProc->proc_interval;
        }

        /* Initialize the output datastreams */

        if (!_dsproc_init_output_datastreams()) {
            exit_value = dsproc_finish();
            exit(exit_value);
        }

        /* Initialize the Retriever */

        if (!_dsproc_init_retriever()) {
            exit_value = dsproc_finish();
            exit(exit_value);
        }

        if ((proc_model & DSP_RETRIEVER_REQUIRED) &&
            !_DSProc->retriever) {

            ERROR( DSPROC_LIB_NAME,
                "Could not find retriever definition in database\n");

            dsproc_set_status(DSPROC_ENORETRIEVER);
            exit_value = dsproc_finish();
            exit(exit_value);
        }
    }

    return;

MEMORY_ERROR:

    fprintf(stderr,
        "%s: Memory allocation error initializing process\n",
        program_name);

    _dsproc_destroy();
    exit(1);
}

/**
 *  Start a processing interval loop.
 *
 *  This function will:
 *    - check if the process has (or will) exceed the maximum run time.
 *    - determine the begin and end times of the next processing interval.
 *
 *  @param  interval_begin - output: begin time of the processing interval
 *  @param  interval_end   - output: end time of the processing interval
 *
 *  @return
 *    - 1 if the next processing interval was returned
 *    - 0 if processing is complete
 */
int dsproc_start_processing_loop(
    time_t *interval_begin,
    time_t *interval_end)
{
    time_t time_remaining;
    char   begin_string[32];
    char   end_string[32];

    *interval_begin = 0;
    *interval_end   = 0;

    /* Check the run time */

    if (_DSProc->loop_begin != 0) {
        _DSProc->loop_end = time(NULL);
    }

    time_remaining = dsproc_get_time_remaining();

    if (time_remaining >= 0) {

        if (time_remaining == 0) {
            return(0);
        }
        else if ((_DSProc->loop_end - _DSProc->loop_begin) > time_remaining) {

            LOG( DSPROC_LIB_NAME,
                "\nStopping vap before max run time of %d seconds is exceeded\n",
                (int)dsproc_get_max_run_time());

            dsproc_set_status(DSPROC_ERUNTIME);
            return(0);
        }
    }

    _DSProc->loop_begin = time(NULL);

    /* Determine the begin and end time of the next processing interval */

    if (_DSProc->interval_begin == 0) {

        _DSProc->cmd_line_begin += _DSProc->interval_offset;
        _DSProc->cmd_line_end   += _DSProc->interval_offset;

        _DSProc->interval_begin  = _DSProc->cmd_line_begin;
    }
    else {
        _DSProc->interval_begin += _DSProc->proc_interval;
    }

    _DSProc->interval_end = _DSProc->interval_begin
                          + _DSProc->proc_interval;

    if (_DSProc->interval_end > _DSProc->cmd_line_end) {

        if (_DSProc->interval_begin == _DSProc->cmd_line_begin) {
            _DSProc->interval_end = _DSProc->cmd_line_end;
        }
        else {
            return(0);
        }
    }

    *interval_begin = _DSProc->interval_begin;
    *interval_end   = _DSProc->interval_end;

    /* Print debug and log messages */

    format_secs1970(*interval_begin, begin_string);
    format_secs1970(*interval_end, end_string);

    DEBUG_LV1_BANNER( DSPROC_LIB_NAME,
        "PROCESSING DATA:\n"
        " - from: %s\n"
        " - to:   %s\n",
        begin_string, end_string);

    LOG( DSPROC_LIB_NAME,
        "\nProcessing data: %s -> %s\n",
        begin_string, end_string);

    /* Update all datastream DODs for the current processing interval */

    if (!dsproc_update_datastream_dsdods(*interval_begin)) {
        return(0);
    }

    return(1);
}

/**
 *  Finish a data system process.
 *
 *  This function will:
 *
 *    - Update the process status in the database
 *    - Log all process stats that were recorded
 *    - Disconnect from the database
 *    - Mail all messages that were generated
 *    - Close the process log file
 *    - Free all memory used by the internal DSProc structure
 *
 *  @return  suggested program exit value (0 = success, 1 = failure)
 *
 *  @see dsproc_init()
 */
int dsproc_finish(void)
{
    ProcStatus *proc_status      = (ProcStatus *)NULL;
    char       *last_status_text = (char *)NULL;
    time_t      last_successful  = 0;
    time_t      last_completed   = 0;
    int         no_data_found    = 0;
    int         no_data_ok       = 0;
    int         total_records    = 0;
    int         total_files      = 0;
    int         successful;
    const char *status_name;
    const char *status_text;
    char       *status_message;
    char        status_note[128];
    time_t      delta_t;
    time_t      finish_time;
    char        finish_time_string[32];
    int         mail_error_status;
    DataStream *ds;
    int         dsi;
    char       *hostname;
    char        time_string1[32];
    char        time_string2[32];
    int         exit_value;

    DEBUG_LV1_BANNER( DSPROC_LIB_NAME,
        "EXITING PROCESS\n");

    /************************************************************
    *  Log output data and file stats
    *************************************************************/

    for (dsi = 0; dsi < _DSProc->ndatastreams; dsi++) {

        ds = _DSProc->datastreams[dsi];

        if (ds->role != DSR_OUTPUT) {
            continue;
        }

        if (ds->begin_time.tv_sec) {

            format_timeval(&(ds->begin_time), time_string1);

            if (ds->end_time.tv_sec) {
                format_timeval(&(ds->end_time), time_string2);
            }
            else {
                strcpy(time_string2, "none");
            }

            LOG( DSPROC_LIB_NAME,
                "\n"
                "Datastream Stats: %s\n"
                " - begin time:    %s\n"
                " - end time:      %s\n",
                ds->name, time_string1, time_string2);

            if (ds->total_files) {

                LOG( DSPROC_LIB_NAME,
                    " - total files:   %d\n"
                    " - total bytes:   %lu\n",
                    ds->total_files, (unsigned long)ds->total_bytes);

                total_files += ds->total_files;
            }

            if (ds->total_records) {

                LOG( DSPROC_LIB_NAME,
                    " - total records: %d\n",
                    ds->total_records);

                total_records += ds->total_records;
            }
        }
    }

    /************************************************************
    *  Set status_name and status_text values
    *************************************************************/

    status_text = _DSProc->status;
    if (status_text[0] == '\0') {
        if (total_files || total_records) {
            status_text = DSPROC_SUCCESS;
        }
        else {
            status_text = DSPROC_ENODATA;
        }
    }

    if (strcmp(status_text, DSPROC_SUCCESS) == 0) {
        status_name = "Success";
        successful  = 1;
    }
    else if (strcmp(status_text, DSPROC_ENODATA) == 0) {
        status_name   = "NoDataFound";
        successful    = 0;
        no_data_found = 1;
    }
    else if (strcmp(status_text, DSPROC_ERUNTIME) == 0) {
        status_name   = "MaxRuntimeExceeded";
        successful    = 0;
    }
    else {
        status_name = "Failure";
        successful  = 0;
    }

    status_note[0] = '\0';

    /************************************************************
    *  Set the process status in the database
    *************************************************************/

    finish_time = time(NULL);

    if (!_DisableDBUpdates) {

        if (dsproc_db_connect()) {

            DEBUG_LV1( DSPROC_LIB_NAME,
                "Updating process status in database\n");

            /* Check if we need to disable the process */

            if (_DSProc->disable[0] != '\0') {

                ERROR( DSPROC_LIB_NAME,
                    "Disabling Process: %s\n", _DSProc->disable);

                finish_time = time(NULL);

                dsdb_update_process_state(_DSProc->dsdb,
                    _DSProc->site, _DSProc->facility, _DSProc->type, _DSProc->name,
                    "AutoDisabled", _DSProc->disable, finish_time);
            }

            /* Get the status of the last run */

            dsdb_get_process_status(_DSProc->dsdb,
                _DSProc->site, _DSProc->facility, _DSProc->type, _DSProc->name,
                &proc_status);

            if (proc_status) {
                last_status_text = proc_status->text;
                last_successful  = proc_status->last_successful;
                last_completed   = proc_status->last_completed;
            }

            /*  Update the status in the database...
             *
             *  We do not want to update the status in the database if no
             *  input data was found and the data expectation interval is
             *  greater than the difference between the process start time
             *  and the last successful time.
             */

            if (no_data_found) {

                delta_t = _DSProc->start_time - last_successful;

                if (_DSProc->data_interval > delta_t) {

                    status_name = "Success";
                    status_text = DSPROC_SUCCESS;
                    no_data_ok  = 1;
                    successful  = 1;

                    snprintf(status_note, 128,
                        " -> No input data was found but we are within\n"
                        " -> the data expectation interval of %g hours.\n",
                        (double)_DSProc->data_interval/3600);
                }
            }

            finish_time = time(NULL);

            if (no_data_ok) {
                dsdb_update_process_completed(_DSProc->dsdb,
                    _DSProc->site, _DSProc->facility, _DSProc->type, _DSProc->name,
                    finish_time);
            }
            else {
                dsdb_update_process_status(_DSProc->dsdb,
                    _DSProc->site, _DSProc->facility, _DSProc->type, _DSProc->name,
                    status_name, status_text, finish_time);
            }

            /* Store any updated datastream times */

            _dsproc_store_output_datastream_times();

            /* Close database connection */

            dsproc_db_disconnect();
        }
        else {

            ERROR( DSPROC_LIB_NAME,
                "Could not update process status in database:\n"
                " -> database connect error\n");

            snprintf(status_note, 128,
                " -> Could not update status in database\n");
        }
    }

    /************************************************************
    *  Create the status message
    *************************************************************/

    hostname = dsenv_get_hostname();
    if (!hostname) {
        hostname = "unknown";
    }

    format_secs1970(finish_time, finish_time_string);

    status_message = msngr_create_string(
        "Current Status (%s):\n"
        "Process: %s%s-%s-%s\n"
        "Version: %s\n"
        "Host:    %s\n"
        "Status:  %s\n"
        "%s",
        finish_time_string,
        _DSProc->site, _DSProc->facility, _DSProc->name, _DSProc->type,
        _DSProc->version, hostname, status_text, status_note);

    if (!status_message) {

        ERROR( DSPROC_LIB_NAME,
            "Could not create status message\n"
            " -> memory allocation error\n");
    }

    /************************************************************
    *  Add process status to the mail messages
    *************************************************************/

    if (!_DisableMail) {

        DEBUG_LV1( DSPROC_LIB_NAME,
            "Adding process status to mail messages\n");

        /* Error Mail */

        mail_error_status = 1;

        if (successful) {
            mail_error_status = 0;
        }
        else if (last_status_text) {
            if (strcmp(last_status_text, status_text) == 0) {
                mail_error_status = 0;
            }
        }

        _finish_mail(MSNGR_ERROR, mail_error_status, status_message,
            last_status_text, last_completed, last_successful, finish_time_string);

        /* Warning Mail */

        _finish_mail(MSNGR_WARNING, 0, status_message,
            last_status_text, last_completed, last_successful, finish_time_string);

        /* Maintainer Mail */

        _finish_mail(MSNGR_MAINTAINER, 0, status_message,
            last_status_text, last_completed, last_successful, finish_time_string);
    }

    /************************************************************
    *  Add process status to the log file
    *************************************************************/

    DEBUG_LV1( DSPROC_LIB_NAME,
        "Adding process status to log file\n");

    if (status_message) {

        LOG( DSPROC_LIB_NAME,
            "\n%s", status_message);

        free(status_message);
    }

    /************************************************************
    *  Send the mail and close the log file
    *************************************************************/

    msngr_finish();

    /************************************************************
    *  Free the memory
    *************************************************************/

    if (proc_status) {
        dsdb_free_process_status(proc_status);
    }

    _dsproc_destroy();

    /************************************************************
    *  Set suggested program exit value
    *************************************************************/

    exit_value = (successful) ? 0 : 1;

    if (msngr_debug_level || msngr_provenance_level) {

        if (successful) {
            DEBUG_LV1( DSPROC_LIB_NAME,
                "Suggested exit value: %d (successful)\n", exit_value);
        }
        else {
            DEBUG_LV1( DSPROC_LIB_NAME,
                "Suggested exit value: %d (failure)\n", exit_value);
        }
    }

    return(exit_value);
}

/************************************************************
 *  Print the contents of the internal DSProc structure.
 *
 *  @param  fp - pointer to the output file
 */
/*

BDE: None of this has been updated in a looooong time, and a lot has been
added. I leave it here in the off chance I will want/need it again...

void dsproc_print_info(FILE *fp)
{
    DSClass   *dsc;
    DSDOD     *dsdod;
    DataTimes *data_times;
    LogFile   *log;
    Mail      *mail;
    char       time_string1[32];
    char       time_string2[32];
    int        i;

    if (!_DSProc) {
        fprintf(fp,
            "Datasystem process has not been initialized.\n");
    }

    if (_DSProc->dsdb && _DSProc->dsdb->dbconn) {
        fprintf(fp,
        "\n"
        "Database Host:   %s\n"
        "Database Name:   %s\n"
        "Database User:   %s\n",
        _DSProc->dsdb->dbconn->db_host,
        _DSProc->dsdb->dbconn->db_name,
        _DSProc->dsdb->dbconn->db_user);
    }

    fprintf(fp,
        "\n"
        "Site:            %s\n"
        "Facility:        %s\n"
        "Process Name:    %s\n"
        "Process Type:    %s\n"
        "Process Version: %s\n",
        _DSProc->site, _DSProc->facility, _DSProc->name, _DSProc->type,
        _DSProc->version);

    format_secs1970(_DSProc->start_time, time_string1);
    format_secs1970(_DSProc->min_valid_time, time_string2);

    fprintf(fp,
        "\n"
        "Start Time:      %s\n"
        "Max Run Time:    %d seconds\n"
        "Min Valid Time:  %s\n",
        time_string1, (int)_DSProc->max_run_time, time_string2);

    if (_DSProc->location) {
        fprintf(fp,
        "\n"
        "Location:        %s\n"
        "Latitude:        %g N\n"
        "Longitude:       %g E\n"
        "Altitude:        %g MSL\n",
        _DSProc->location->name,
        _DSProc->location->lat,
        _DSProc->location->lon,
        _DSProc->location->alt);
    }

    log = msngr_get_log_file();

    if (log) {
        fprintf(fp,
        "\n"
        "Log File Path:   %s\n"
        "Log File Name:   %s\n",
        log->path, log->name);
    }

    mail = msngr_get_mail(MSNGR_ERROR);
    if (mail) {
        fprintf(fp,
        "\n"
        "Error Mail:      %s\n", mail->to);
    }

    mail = msngr_get_mail(MSNGR_WARNING);
    if (mail) {
        fprintf(fp,
        "Warning Mail:    %s\n", mail->to);
    }

    mail = msngr_get_mail(MSNGR_MAINTAINER);
    if (mail) {
        fprintf(fp,
        "Mentor Mail:     %s\n", mail->to);
    }

    if (_DSProc->data_interval) {
        fprintf(fp,
        "\n"
        "Expected Data Interval:   %d seconds\n", (int)_DSProc->data_interval);
    }

    if (_DSProc->proc_interval) {
        fprintf(fp,
        "\n"
        "Data Processing Interval: %d seconds\n", (int)_DSProc->proc_interval);
    }

    if (_DSProc->ndsc_inputs) {
        fprintf(fp,
        "\n"
        "Input Datastream Classes:\n"
        "\n");

        for (i = 0; i < _DSProc->ndsc_inputs; i++) {
            dsc = _DSProc->dsc_inputs[i];
            fprintf(fp, "    %s.%s\n", dsc->name, dsc->level);
        }
    }

    if (_DSProc->ndsc_outputs) {
        fprintf(fp,
        "\n"
        "Output Datastream Classes:\n"
        "\n");

        for (i = 0; i < _DSProc->ndsc_outputs; i++) {
            dsc = _DSProc->dsc_outputs[i];
            fprintf(fp, "    %s.%s\n", dsc->name, dsc->level);
        }
    }

    if (_DSProc->ndsdods) {
        fprintf(fp,
        "\n"
        "Loaded Datastream DODs:\n"
        "\n");

        for (i = 0; i < _DSProc->ndsdods; i++) {
            dsdod = _DSProc->dsdods[i];

            fprintf(fp,
            "    %s%s%s.%s-%s\n",
            _DSProc->site, dsdod->name, _DSProc->facility, dsdod->level,
            dsdod->version);
        }
    }

    if (_DSProc->ndatatimes) {
        fprintf(fp,
        "\n"
        "Previously Processed Data Times:\n");

        for (i = 0; i < _DSProc->ndatatimes; i++) {

            data_times = _DSProc->data_times[i];

            if (data_times->begin_time.tv_sec) {
                format_timeval(&data_times->begin_time, time_string1);
            }
            else {
                strcpy(time_string1, "N/A");
            }

            if (data_times->end_time.tv_sec) {
                format_timeval(&data_times->end_time, time_string2);
            }
            else {
                strcpy(time_string2, "N/A");
            }

            fprintf(fp,
            "\n"
            "    %s%s%s.%s\n"
            "     - begin time: %s\n"
            "     - end time:   %s\n",
            _DSProc->site, data_times->dsc_name, _DSProc->facility,
            data_times->dsc_level,
            time_string1,
            time_string2);
        }
    }

    if (_DSProc->input_dir) {
        fprintf(fp,
        "\n"
        "Input Directory: %s\n", _DSProc->input_dir);
    }

    if (_DSProc->file_patterns) {
        fprintf(fp,
        "\n"
        "File Patterns:\n"
        "\n");

        for (i = 0; i < _DSProc->npatterns; i++) {
            fprintf(fp,
            "    %s\n", _DSProc->file_patterns[i]);
        }
    }
}
*/

/*******************************************************************************
 *  Public Functions
 */
/** @publicsection */

/**
 *  Get the process status.
 *
 *  @return  process status message
 */
const char *dsproc_get_status(void)
{
    return(_DSProc->status);
}

/**
 *  Set the process status.
 *
 *  @param  status - process status message
 */
void dsproc_set_status(const char *status)
{
    DEBUG_LV1( DSPROC_LIB_NAME,
        "Setting status to: '%s'\n", status);

    strncpy((char *)_DSProc->status, status, 511);
}

/**
 *  Get the process site.
 *
 *  @return  site name
 */
const char *dsproc_get_site(void)
{
    return(_DSProc->site);
}

/**
 *  Get the process facility.
 *
 *  @return  facility
 */
const char *dsproc_get_facility(void)
{
    return(_DSProc->facility);
}

/**
 *  Get the process name.
 *
 *  @return  process name
 */
const char *dsproc_get_name(void)
{
    return(_DSProc->name);
}

/**
 *  Get the process type.
 *
 *  @return  process type
 */
const char *dsproc_get_type(void)
{
    return(_DSProc->type);
}

/**
 *  Get the process version.
 *
 *  @return  process version
 */
const char *dsproc_get_version(void)
{
    return(_DSProc->version);
}
