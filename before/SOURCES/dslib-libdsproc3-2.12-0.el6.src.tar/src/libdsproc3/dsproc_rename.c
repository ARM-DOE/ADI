/*******************************************************************************
*
*  COPYRIGHT (C) 2010 Battelle Memorial Institute.  All Rights Reserved.
*
********************************************************************************
*
*  Author:
*     name:  Brian Ermold
*     phone: (509) 375-2277
*     email: brian.ermold@pnl.gov
*
********************************************************************************
*
*  REPOSITORY INFORMATION:
*    $Revision: 50680 $
*    $Author: ermold $
*    $Date: 2014-01-07 03:22:38 +0000 (Tue, 07 Jan 2014) $
*
********************************************************************************
*
*  NOTE: DOXYGEN is used to generate documentation for this file.
*
*******************************************************************************/

/** @file dsproc_rename.c
 *  File Renaming Functions.
 */

#include "dsproc3.h"
#include "dsproc_private.h"

extern DSProc *_DSProc; /**< Internal DSProc structure */

/** @privatesection */

/*******************************************************************************
 *  Static Functions Visible Only To This Module
 */

/**
 *  Static: Rename a data file.
 *
 *  This function will rename a raw data file into the datastream directory
 *  using the datastream name and begin_time to give it a fully qualified
 *  ARM name.
 *
 *  The begin_time will be validated using:
 *
 *      dsproc_validate_datastream_data_time()
 *
 *  If the end_time is specified, this function will verify that it is greater
 *  than the begin_time and is not in the future. If only one record was found
 *  in the raw file, the end_time argument must be set to NULL.
 *
 *  If the output file exists and has the same MD5 as the input file,
 *  the input file will be removed and a warning message will be generated.
 *
 *  If the output file exists and has a different MD5 than the input
 *  file, the rename will fail.
 *
 *  If an error occurs in this function it will be appended to the log and
 *  error mail messages, and the process status will be set appropriately.
 *
 *  @param  ds_id      - datastream ID
 *  @param  file_path  - path to the directory the file is in
 *  @param  file_name  - name of the file to rename
 *  @param  begin_time - time of the first record in the file
 *  @param  end_time   - time of the last record in the file
 *  @param  extension  - extension to use when renaming the file, or NULL to
 *                       use the default extension for the datastream format.
 *
 *  @return
 *    - 1 if successful
 *    - 0 if an error occurred
 */
static int _dsproc_rename(
    int              ds_id,
    const char      *file_path,
    const char      *file_name,
    const timeval_t *begin_time,
    const timeval_t *end_time,
    const char      *extension)
{
    DataStream *ds  = _DSProc->datastreams[ds_id];
    time_t      now = time(NULL);
    char        src_file[PATH_MAX];
    struct stat src_stats;
    char        src_md5[64];
    char        done_dir[PATH_MAX];
    char       *dest_path;
    char        dest_name[256];
    char        dest_file[PATH_MAX];
    char        dest_md5[64];
    struct tm   time_stamp_tm;
    char        time_stamp[32];
    char        time_string1[32];
    char        time_string2[32];
    const char *preserve;
    int         dot_count;
    char        rename_error[2*PATH_MAX];
    int         rename_file;

    memset(&time_stamp_tm, 0, sizeof(struct tm));

    DEBUG_LV1( DSPROC_LIB_NAME,
        "%s: Renaming file: %s/%s\n",
        ds->name, file_path, file_name);

    /************************************************************
    *  Get source file stats
    *************************************************************/

    snprintf(src_file, PATH_MAX, "%s/%s", file_path, file_name);

    if (access(src_file, F_OK) != 0) {

        ERROR( DSPROC_LIB_NAME,
            "Could not rename file: %s\n"
            " -> file does not exist\n", src_file);

        dsproc_set_status(DSPROC_ENOSRCFILE);
        return(0);
    }

    if (stat(src_file, &src_stats) < 0) {

        ERROR( DSPROC_LIB_NAME,
            "Could not rename file: %s\n"
            " -> stat error: %s\n", src_file, strerror(errno));

        dsproc_set_status(DSPROC_EFILESTATS);
        return(0);
    }

    /************************************************************
    *  Validate datastream times
    *************************************************************/

    /* validate begin time */

    if (!begin_time || !begin_time->tv_sec) {

        ERROR( DSPROC_LIB_NAME,
            "Could not rename file: %s\n"
            " -> file time not specified\n", src_file);

        dsproc_set_status(DSPROC_ENOFILETIME);
        return(0);
    }

    if (!dsproc_validate_datastream_data_time(ds_id, begin_time)) {

        ERROR( DSPROC_LIB_NAME,
            "Could not rename file: %s\n"
            " -> time validation error\n", src_file);

        return(0);
    }

    /* validate end time */

    if (end_time && end_time->tv_sec) {

        if (TV_LTEQ(*end_time, *begin_time)) {

            format_timeval(begin_time, time_string2);
            format_timeval(end_time,   time_string1);

            ERROR( DSPROC_LIB_NAME,
                "Could not rename file: %s\n"
                " -> end time '%s' <= begin time '%s'\n",
                src_file, time_string1, time_string2);

            dsproc_set_status(DSPROC_ETIMEORDER);
            return(0);
        }
        else if (end_time->tv_sec > now) {

            format_timeval(end_time, time_string1);
            format_secs1970(now, time_string2);

            ERROR( DSPROC_LIB_NAME,
                "Could not rename file: %s\n"
                " -> data time '%s' is in the future (current time is: %s)\n",
                src_file, time_string1, time_string2);

            dsproc_disable(DSPROC_EFUTURETIME);
            return(0);
        }
    }

    /************************************************************
    *  Determine the portion of the original file name to preserve
    *************************************************************/

    preserve = (const char *)NULL;

    if (ds->preserve_dots > 0) {

        dot_count = 0;

        for (preserve = file_name + strlen(file_name) - 1;
             preserve != file_name;
             preserve--) {

            if (*preserve == '.') {
                dot_count++;
                if (dot_count == ds->preserve_dots) {
                    preserve++;
                    break;
                }
            }
        }
    }

    /************************************************************
    *  Get the full path to the destination directory
    *************************************************************/

    snprintf(done_dir, PATH_MAX, "%s/.done", file_path);

    if (access(done_dir, F_OK) == 0) {
        dest_path = done_dir;
    }
    else {

        dest_path = ds->dir->path;

        /* Make sure the destination directory exists */

        if (!make_path(dest_path, 0775)) {

            ERROR( DSPROC_LIB_NAME,
                "Could not rename file: %s\n"
                " -> make_path failed for: %s\n",
                src_file, dest_path);

            dsproc_set_status(DSPROC_EDESTDIRMAKE);
            return(0);
        }
    }

    /************************************************************
    *  Create the time stamp for the destination file
    *************************************************************/

    if (!gmtime_r(&begin_time->tv_sec, &time_stamp_tm)) {

        ERROR( DSPROC_LIB_NAME,
            "Could not rename file: %s\n"
            " -> gmtime error: %s\n",
            src_file, strerror(errno));

        dsproc_set_status(DSPROC_ETIMECALC);
        return(0);
    }

    strftime(time_stamp, 32, "%Y%m%d.%H%M%S", &time_stamp_tm);

    /************************************************************
    *  Create the output file name
    *************************************************************/

    if (!extension) {
        extension = ds->extension;
    }

    if (preserve) {
        snprintf(dest_name, 256, "%s.%s.%s.%s",
            ds->name, time_stamp, extension, preserve);
    }
    else {
        snprintf(dest_name, 256, "%s.%s.%s",
            ds->name, time_stamp, extension);
    }

    snprintf(dest_file, PATH_MAX, "%s/%s", dest_path, dest_name);

    /************************************************************
    *  Check if the output file already exists
    *************************************************************/

    rename_file = 1;

    if (access(dest_file, F_OK) == 0) {

        sprintf(rename_error,
            "\n"
            "Found existing destination file while renaming source file:\n"
            " -> from: %s\n"
            " -> to:   %s\n",
            src_file, dest_file);

        /* Check the MD5s */

        if (!file_get_md5(src_file, src_md5)) {

            ERROR( DSPROC_LIB_NAME,
                "%s -> could not get source file MD5\n",
                rename_error);

            dsproc_set_status(DSPROC_EFILEMD5);
            return(0);
        }

        if (!file_get_md5(dest_file, dest_md5)) {

            ERROR( DSPROC_LIB_NAME,
                "%s -> could not get destination file MD5\n",
                rename_error);

            dsproc_set_status(DSPROC_EFILEMD5);
            return(0);
        }

        if (strcmp(src_md5, dest_md5) == 0) {

            /* The MD5s match so delete the input file */

            if (unlink(src_file) < 0) {

                ERROR( DSPROC_LIB_NAME,
                    "%s"
                    " -> source and destination files have matching MD5s\n"
                    " -> could not delete source file: %s\n",
                    rename_error, strerror(errno));

                dsproc_set_status(DSPROC_EUNLINK);
                return(0);
            }

            WARNING( DSPROC_LIB_NAME,
                "%s"
                " -> source and destination files have matching MD5s\n"
                " -> deleted source file\n",
                rename_error);

            rename_file = 0;
        }
        else {

            /* The MD5s do not match */

            ERROR( DSPROC_LIB_NAME,
                "%s"
                " -> source and destination files have different MD5s\n",
                rename_error);

            dsproc_set_status(DSPROC_EMD5CHECK);
            return(0);
        }
    }

    /************************************************************
    *  Rename the file
    *************************************************************/

    if (rename_file) {

        LOG( DSPROC_LIB_NAME,
            "Renaming:   %s\n"
            " -> to:     %s\n",
            src_file, dest_file);

        if (!file_move(src_file, dest_file, FC_CHECK_MD5)) {
            dsproc_set_status(DSPROC_EFILEMOVE);
            return(0);
        }

        /* Update the access and modification times */

        utime(dest_file, NULL);
    }

    /************************************************************
    *  Update the datastream file stats
    *************************************************************/

    dsproc_update_datastream_file_stats(
        ds_id, (double)src_stats.st_size, begin_time, end_time);

    return(1);
}

/*******************************************************************************
 *  Private Functions Visible Only To This Library
 */

/** @publicsection */

/*******************************************************************************
 *  Internal Functions Visible To The Public
 */

/*******************************************************************************
 *  Public Functions
 */

/**
 *  Rename a data file.
 *
 *  This function will rename a raw data file into the datastream directory
 *  using the datastream name and begin_time to give it a fully qualified
 *  ARM name.
 *
 *  The begin_time will be validated using:
 *
 *      dsproc_validate_datastream_data_time()
 *
 *  If the end_time is specified, this function will verify that it is greater
 *  than the begin_time and is not in the future. If only one record was found
 *  in the raw file, the end_time argument must be set to NULL.
 *
 *  If the output file exists and has the same MD5 as the input file,
 *  the input file will be removed and a warning message will be generated.
 *
 *  If the output file exists and has a different MD5 than the input
 *  file, the rename will fail.
 *
 *  If an error occurs in this function it will be appended to the log and
 *  error mail messages, and the process status will be set appropriately.
 *
 *  @param  ds_id      - datastream ID
 *  @param  file_path  - path to the directory the file is in
 *  @param  file_name  - name of the file to rename
 *  @param  begin_time - time of the first record in the file
 *  @param  end_time   - time of the last record in the file
 *
 *  @return
 *    - 1 if successful
 *    - 0 if an error occurred
 */
int dsproc_rename(
    int         ds_id,
    const char *file_path,
    const char *file_name,
    time_t      begin_time,
    time_t      end_time)
{
    timeval_t begin = {0, 0};
    timeval_t end   = {0, 0};

    begin.tv_sec = begin_time;
    end.tv_sec   = end_time;

    return(_dsproc_rename(
        ds_id, file_path, file_name, &begin, &end, NULL));
}

/**
 *  Rename a data file.
 *
 *  This function is the same as dsproc_rename() except that it
 *  takes timevals for the begin and end times.
 *
 *  If an error occurs in this function it will be appended to the log and
 *  error mail messages, and the process status will be set appropriately.
 *
 *  @param  ds_id      - datastream ID
 *  @param  file_path  - path to the directory the file is in
 *  @param  file_name  - name of the file to rename
 *  @param  begin_time - time of the first record in the file
 *  @param  end_time   - time of the last record in the file
 *
 *  @return
 *    - 1 if successful
 *    - 0 if an error occurred
 */
int dsproc_rename_tv(
    int              ds_id,
    const char      *file_path,
    const char      *file_name,
    const timeval_t *begin_time,
    const timeval_t *end_time)
{
    return(_dsproc_rename(
        ds_id, file_path, file_name, begin_time, end_time, NULL));
}

/**
 *  Rename a bad data file.
 *
 *  This function works the same as dsproc_rename() except that the
 *  extension "bad" will be used in the output file name.
 *
 *  If an error occurs in this function it will be appended to the log and
 *  error mail messages, and the process status will be set appropriately.
 *
 *  @param  ds_id      - datastream ID
 *  @param  file_path  - path to the directory the file is in
 *  @param  file_name  - name of the file to rename
 *  @param  file_time  - the time used to rename the file
 *
 *  @return
 *    - 1 if successful
 *    - 0 if an error occurred
 */
int dsproc_rename_bad(
    int         ds_id,
    const char *file_path,
    const char *file_name,
    time_t      file_time)
{
    timeval_t begin = {0, 0};

    begin.tv_sec = file_time;

    return(_dsproc_rename(
        ds_id, file_path, file_name, &begin, NULL, "bad"));
}

/**
 *  Set the portion of file names to preserve when they are renamed.
 *
 *  This is the number of dots from the end of the file name and specifies
 *  the portion of the original file name to preserve when it is renamed.
 *
 *  Default value set if preserve_dots < 0:
 *
 *    - 2 for level '0' datastreams
 *    - 0 for all other datastreams
 *
 *  @param  ds_id         - output datastream ID
 *  @param  preserve_dots - portion of original file name to preserve
 */
void dsproc_set_rename_preserve_dots(int ds_id, int preserve_dots)
{
    DataStream *ds = _DSProc->datastreams[ds_id];

    if (preserve_dots < 0) {
        preserve_dots = (ds->dsc_level[0] == '0') ? 2: 0;
    }

    DEBUG_LV1( DSPROC_LIB_NAME,
        "%s: Setting rename preserve dots value to: %d\n",
        ds->name, preserve_dots);

    ds->preserve_dots = preserve_dots;
}

/*@}*/
